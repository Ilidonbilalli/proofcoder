# ProofCoder Kit

A compact, execution-verified coding-agent harness and training-data pipeline for a 27B open model. Designed around a simple idea: **the model proposes an action; the environment supplies evidence; only verified work becomes training data.**

This is a research baseline, not a promise of Terminal-Bench 4.0 50–55%, DeepSWE v1.1 77%, or frontier-model parity. Those require measured gains over a frozen baseline and substantially more training compute than two T4s provide.

## What is included

- **Small harness:** one `<bash>` or `<done>` action per turn, linear history, deterministic compaction, full JSONL audit, loop guards, final-test gate.
- **Safe execution:** disposable Docker with no network, no host mounts, dropped capabilities, CPU/RAM/PID limits.
- **Training data:** strict final verification, historical prompt preservation, benchmark-provenance blocking, protocol-error rejection, global near-duplicate rejection, per-repo caps, repository-grouped splits, and same-task verified DPO pairs.
- **27B QLoRA:** NF4 + double quantization + FP16 compute + paged optimizer + gradient checkpointing; model parallel across two GPUs.
- **Web anti-slop gate:** local asset checks, JS parsing, Chromium exceptions/console checks, screenshots, and a basic canvas/input check.
- **Evaluation:** frozen manifests, multiple trials, safe resume, immutable reports, token/runtime/tool metrics, pass@1 vs task-any, Wilson intervals, and model/runner/harness/config hashes.

## 1. Hardware reality for Kaggle 2×T4

Each T4 has 16 GB VRAM. A 27B model at ideal 4 bits is 13.5 GB before quantization metadata, runtime buffers, KV cache, adapters, gradients, and activations.

- **Inference and training must be separate jobs.** Do not leave the Q4 inference server resident while training.
- **Training data belongs on CPU RAM/disk, not VRAM.** VRAM is for weights, KV cache, adapters, gradients, and activations.
- Use the **HF/Transformers model for QLoRA**, not a GGUF file. GGUF Q4 is for llama.cpp inference.
- T4 is Turing: use **FP16 compute, not BF16**. FlashAttention support varies; the training config defaults to eager attention.
- Start at sequence length 2048, micro-batch 1, gradient accumulation 16. Increase only after measuring peak memory. Two T4s do not pool memory automatically; `device_map=balanced` uses model parallelism and can be slow across PCIe.
- If 27B QLoRA still OOMs, shorten to 1024, reduce LoRA targets/rank, or use a smaller base. Do not silently disable verification to save money.

## 2. Install and test

```bash
cd proofcoder
python -m pip install -e '.[dev]'
pytest -q
```

Optional real-browser checks:

```bash
python -m pip install -e '.[web]'
playwright install chromium
```

## 3. Serve Q4 inference

Build/install a current `llama.cpp` that provides `llama-server`, then:

```bash
export MODEL_PATH=/absolute/path/to/VeriLoop-E2-Q4_K_M.gguf
bash scripts/serve_gguf.sh
```

Set `PROOFCODER_API_KEY` in the environment before using the CLI. The config pins the official Q4_K_M artifact revision and sends `enable_thinking=false` for the compact action protocol. The default context is 8192; raise it only after observing free VRAM. The backend must return chat completions at `http://127.0.0.1:8000/v1/chat/completions`.

## 4. Run a task

Docker is required for the default runner:

```bash
proofcoder run 'Fix the failing tests. Inspect the repository first.' \
  --config configs/agent.json
```

For web/game tasks, configure a task-specific verifier. Generic checks are only a floor:

```bash
proofcoder web-check /path/to/app --game
# With Chromium installed and a temporary local server:
PYTHONPATH=src python scripts/verify_web.py /path/to/app --game
```

For a Minecraft-like task, add behavioral Playwright tests: world renders, pointer lock or fallback works, movement changes player coordinates, block place/remove changes world state, save/load restores state. A changing screenshot alone is not proof of a working game.

## 5. Generate and curate training data

Use training-only repositories/tasks. Run the frozen harness and retain only externally verified trajectories:

```bash
PYTHONPATH=src python scripts/export_trajectories.py runs/*.jsonl \
  --repo owner/repository --out data/candidates.jsonl
proofcoder curate data/candidates.jsonl --out data/curated \
  --blocked-repos owner/benchmark-repo-1 owner/benchmark-repo-2
```

A useful first corpus is 10k–30k diverse, verified trajectories, not millions of unverified tokens. Start with short successful tasks, then add failure/recovery and longer tasks. Keep roughly the mixture in `configs/curriculum.json`; measure each ablation rather than assuming it helps.

**Never train on the benchmark tasks, their answers, derived near-duplicates, or repositories excluded by the benchmark protocol.** `benchmark_source` in a row causes rejection. Keep a contamination manifest with source licenses, repository commits, task hashes, and exclusion lists.

## 6. Train QLoRA

The config pins `tsinghua-sigs-robot-lab/VeriLoop-E2` at commit `44b6f230347f9ccf2a5ce96a44bcd74ecaaaa51f` (Apache-2.0). Its template has no assistant-loss generation markers, so the training script explicitly masks all non-assistant tokens and drops overlength examples rather than silently training on user/tool text. The loader uses `AutoModelForMultimodalLM`; Transformers 4.57.6 or newer is required.

```bash
# Stop llama-server first.
python -m pip install -e '.[train]'
python scripts/train_qlora.py --config configs/qlora_27b_t4.json
```

Save and evaluate the base model and every adapter under the same Q4 inference configuration. Merging LoRA and requantizing can change behavior; evaluate the exact artifact you will deploy. Merge on a high-RAM CPU host (not a memory-limited T4 notebook), then convert with a current llama.cpp that supports this architecture:

```bash
python scripts/merge_adapter.py --adapter outputs/veriloop-e2-proofcoder-lora/final --output outputs/veriloop-e2-proofcoder-merged
python llama.cpp/convert_hf_to_gguf.py outputs/veriloop-e2-proofcoder-merged --outfile outputs/proofcoder-bf16.gguf --outtype bf16
llama.cpp/build/bin/llama-quantize outputs/proofcoder-bf16.gguf outputs/proofcoder-q4_k_m.gguf Q4_K_M
```

Recommended progression:

1. **Baseline:** base Q4 + frozen harness, no training.
2. **Verified SFT:** short tasks → recovery traces → longer multi-file tasks.
3. **Rejection-sampling SFT:** 4–8 samples per training task, keep concise verified winners.
4. **Preference optimization (optional):** same-task pairs where the winner passes and loser fails real tests.
5. **Online RL (optional, larger GPUs):** execution rewards only after SFT plateaus. Two T4s are not a sensible 27B online-RL setup.

## 7. Benchmark without fooling yourself

Manifest format (`data/tasks.example.jsonl`): `task_id`, `prompt`, `image`, `verifier`.

```bash
PYTHONPATH=src python scripts/run_benchmark.py data/tasks.example.jsonl \
  --config configs/agent.json --trials 3 --out outputs/baseline
proofcoder score outputs/baseline/results.jsonl
```

To resume an interrupted run, repeat the same command with the same output directory. Completed `(task_id, trial)` rows are validated and skipped, extra trials are preserved, and `report.json` is created once without overwriting. Use a new output directory for a finalized report or any changed run configuration. Benchmark audits carry `benchmark_source` and are automatically rejected by training curation.

For Terminal-Bench 4.0 or DeepSWE v1.1, use their official current runner, task images, limits, scoring, and submission rules. Do not substitute this generic manifest score and label it as an official result.

Freeze before running: model/adapter revision, quantization, chat template, system prompt, tool protocol, sampling, max steps/tokens, timeout, retry policy, and task-set hash. Tune on development tasks only. Report:

- attempt-level pass@1 and task-level any-success separately;
- resolved/total and Wilson 95% interval;
- mean steps, timeouts, tokens, wall time, and cost;
- base vs adapter delta under identical harness and budget;
- failures by category: navigation, edit, test, recovery, protocol, timeout.

A target of 50–55% is meaningful only on the same Terminal-Bench 4.0 protocol. A target of 77% likewise needs the exact DeepSWE v1.1 evaluation definition. A single lucky trial is not evidence.

## Kaggle, Tailscale, and OpenCode

See [SETUP.md](SETUP.md) for the full free setup. Ready-to-import notebooks are in `notebooks/`; OpenCode config is `deploy/opencode.json.example`. Tailscale Serve is the primary remote option because Cloudflare Quick Tunnels do not support SSE streaming.

Measure inference speed with:

```bash
python scripts/benchmark_speed.py --model veriloop-e2-27b-q4 --api-key "$PROOFCODER_API_KEY"
```

Build same-task preference pairs and optionally run second-stage DPO:

```bash
proofcoder curate data/candidates.jsonl --out data/curated
PYTHONPATH=src python scripts/export_trajectories.py runs/*.jsonl --repo owner/repository --out data/candidates.jsonl --include-failed
proofcoder preferences data/candidates.jsonl --out data/preferences.jsonl
python scripts/train_dpo.py --config configs/dpo_27b_t4.json
```

DPO is experimental on this memory-constrained setup; use only after verified SFT and evaluate for regressions.

## Design rationale and public sources

See [RESEARCH.md](RESEARCH.md). No leaked proprietary prompt or harness is used.
## Current limitations

- Browser input verification is generic; serious tasks need custom behavioral tests.
- Docker task setup is intentionally minimal; official benchmark images/runners remain authoritative.
- The official VeriLoop E2 model/GGUF revisions and template behavior are verified, but GPU training and inference dependencies are not installed or smoke-tested in this workspace.
- No benchmark score has been run in this workspace; only unit/smoke tests are claimed.
- The model-parallel QLoRA path still needs a real 2×T4 memory smoke run; unit tests do not prove that 27B training fits.
