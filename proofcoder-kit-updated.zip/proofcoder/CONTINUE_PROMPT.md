# Prompt for the next AI

You are continuing `proofcoder/`, an execution-verified coding-agent harness and 27B QLoRA training kit. Read `README.md`, `SETUP.md`, `RESEARCH.md`, all source files, configs, notebooks, and tests first. Run `pytest -q`; the suite currently passes **74 tests**. Do not regress below that. The updated kit is packaged as `proofcoder-kit-updated.zip`.

Hardware: Kaggle 2×NVIDIA T4, 16 GB each. Inference and training run in separate sessions. T4 uses FP16, not BF16. Training data stays on CPU/disk. GGUF Q4 is for llama.cpp inference; the HF model is required for QLoRA/DPO. Official Apache-2.0 artifacts are pinned: HF `tsinghua-sigs-robot-lab/VeriLoop-E2` at `44b6f230347f9ccf2a5ce96a44bcd74ecaaaa51f`; GGUF `tsinghua-sigs-robot-lab/VeriLoop-E2-GGUF`, `VeriLoop-E2-Q4_K_M.gguf`, at `288087d057453f68a1521de6bb5f800f24eb7e9e`.

Current state: compact `<bash>`/`<done>` protocol with thinking disabled; deterministic compaction; unique JSONL audits with historical prompts and provenance; repeated-command, no-progress, protocol-error, backend-error, and hard wall-time guards; honest unverified completion; Docker sandbox; full token/runtime/tool/timeout metrics; safe resume and immutable reports; strict final-verified SFT admission with global near-duplicate rejection; verified same-task preferences; custom assistant-only loss masking for a template without generation markers; official model revisions; web/game checks; Kaggle notebooks; authenticated llama.cpp; Tailscale Serve; OpenCode config; paired comparisons and Wilson intervals.

Goal: improve measurable coding ability. User aspirations are Terminal-Bench 4.0 50–55%, DeepSWE v1.1 77%, 30–50 tok/s, and “20× better coding,” but never promise or fabricate these. Establish deltas with paired baseline/adapter runs and official protocols. No leaked proprietary harnesses, no benchmark-task training, no hidden-test tuning, and no unverified generated code in SFT.

Completed this round: telemetry aggregation; safe resume; trajectory quality scoring; benchmark provenance blocking; interrupted-log rejection; runner-inclusive resume identity; exact model/license/template verification; role-aware assistant-only masking; collision-safe audits; duplicate-manifest rejection; absolute Kaggle training-data paths; end-to-end training/deployment guide.

Next priorities:
1. Run the tiny-model and exact 27B 2×T4 memory smoke tests; record peak VRAM and adjust only measured bottlenecks.
2. Build executable training tasks from permitted real repositories. Generate bug/fix pairs, run tests in isolated environments, keep only verified trajectories, and include concise failure→diagnosis→repair examples. Record repository commits and licenses.
3. Strengthen web/game verification with task-specific Playwright behavior tests for a Minecraft-like HTML game: rendering, controls, player coordinates, block placement/removal, collision, and save/load—not merely screenshots or console absence.
4. Benchmark speed honestly with `scripts/benchmark_speed.py`, then test split mode, context, KV cache, and speculative decoding one variable at a time. Report tok/s, pass@1, steps, and regressions together.
5. Establish a frozen base Q4 + harness baseline before adapter claims. Keep development tasks separate from official Terminal-Bench 4.0/DeepSWE v1.1 tasks. Use official runners for official labels.

Deliver working code, configs, tests, and a concise report. Clearly distinguish unit/smoke tests from actual model training and real benchmark runs; do not claim GPUs or benchmarks were run unless you actually ran them. Finish with exact next commands and a ranked list of remaining bottlenecks.
