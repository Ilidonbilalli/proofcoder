# Free Kaggle → Tailscale → OpenCode setup

This architecture keeps model inference and ProofCoder on Kaggle, GitHub stores code, Tailscale provides private streaming access, and OpenCode runs on your computer. **GitHub is not a persistent harness host**, and OpenCode uses its own harness when connected directly to the model. Run ProofCoder in the Kaggle notebook when you want its trajectory collection/verifier.

## A. Create and verify Kaggle

1. Open https://www.kaggle.com/ and choose **Sign Up**. Use email or Google and confirm your email.
2. Open your profile/account settings. If GPU or Internet is locked, complete **Phone Verification** there.
3. Choose **Create → New Notebook**.
4. In the notebook's right-side **Settings**, choose **Accelerator → GPU T4 x2** and turn **Internet** on.
5. Run `!nvidia-smi`. You should see two T4 GPUs with 16 GB each. If not, recheck the accelerator.
6. Kaggle sessions are temporary. Current official notebook docs list up to 12-hour execution sessions and 20 GB auto-saved `/kaggle/working`; quotas/availability can change. Save important outputs before stopping.

## B. Put ProofCoder on GitHub

1. Create an empty GitHub repository named `proofcoder`; do not initialize it with a README.
2. From the extracted kit directory:

```bash
git init
git add .
git commit -m "ProofCoder training and harness kit"
git branch -M main
git remote add origin https://github.com/YOUR_USER/proofcoder.git
git push -u origin main
```

Do not commit `.env`, API keys, model weights, datasets with restrictive licenses, runs, or outputs. The supplied `.gitignore` excludes common artifacts.

## C. Create the free private Tailscale connection

Tailscale Serve is preferable to Cloudflare Quick Tunnel here: Quick Tunnels officially do not support SSE, while OpenCode may stream responses. Tailscale also avoids exposing the model publicly.

1. Create/sign into a free account at https://tailscale.com/.
2. Open https://console.tailscale.com/admin/settings/keys.
3. Choose **Generate auth key**. For Kaggle, select **Ephemeral**. Use a one-off key for one session; reusable keys are convenient but more sensitive. Keep the default short practical expiry.
4. Copy the `tskey-...` value into a Kaggle Secret named `TAILSCALE_AUTH_KEY`.
5. Install Tailscale on the computer running OpenCode: https://tailscale.com/download. Sign into the **same tailnet**.

## D. Add Kaggle secrets

In the Kaggle notebook choose **Add-ons → Secrets** and add:

- `PROOFCODER_API_KEY`: generate a long random password; this protects llama-server.
- `TAILSCALE_AUTH_KEY`: the key from step C.
- `HF_TOKEN`: only if the model repository requires Hugging Face authentication.

Enable notebook access for each secret. Never paste these into notebook source or GitHub.

## E. Choose and prepare the model

1. The serving notebook pins the official `tsinghua-sigs-robot-lab/VeriLoop-E2-GGUF` repository, `VeriLoop-E2-Q4_K_M.gguf`, and revision `288087d057453f68a1521de6bb5f800f24eb7e9e` (Apache-2.0).
2. Training separately pins `tsinghua-sigs-robot-lab/VeriLoop-E2` at `44b6f230347f9ccf2a5ce96a44bcd74ecaaaa51f`. GGUF cannot be used by the QLoRA script.
3. In `notebooks/kaggle_serve.ipynb`, replace only `PROOFCODER_REPO` with your GitHub URL unless you intentionally change the model artifact.
4. Import the notebook using Kaggle **File → Import Notebook**, or create a notebook and copy its cells.
5. Run cells in order. Building llama.cpp and downloading 27B weights takes time. The service cell prints `PRIVATE_BASE_URL`; it does not print secrets.
6. The speed cell reports actual decode tok/s. Test configurations separately rather than assuming 30–50 tok/s.

If llama-server exits, inspect:

```bash
!tail -n 100 /kaggle/working/logs/llama-server.log
!nvidia-smi
```

Common causes are wrong GGUF filename, insufficient VRAM, an incompatible llama.cpp build, or another GPU process still running.

## F. Connect OpenCode

1. Install OpenCode. On Windows with Node.js:

```bash
npm install -g opencode-ai
```

2. Copy `deploy/opencode.json.example` to `opencode.json` in the coding project.
3. Replace `baseURL` with the printed `PRIVATE_BASE_URL`. Keep `/v1` and the model id `veriloop-e2-27b-q4`.
4. Set the API key in your shell:

```bash
export PROOFCODER_API_KEY='the-same-long-random-secret'
```

On Windows PowerShell use `$env:PROOFCODER_API_KEY='the-same-long-random-secret'`.
5. Start `opencode`, run `/connect`, choose **Other**, enter provider id `proofcoder`, and enter the API key. Then run `/models` and select **VeriLoop E2 27B Q4**.
6. Test “Reply with OK,” then a small coding task. If streaming fails, verify the Tailscale connection first; do not disable authentication.

## G. Run the hosted ProofCoder harness

The serving notebook's final cell runs ProofCoder on Kaggle's disposable worker. Modify its task and verifier for real jobs. `--local` means commands run inside the ephemeral Kaggle environment; it is not the same safety boundary as Docker.

For benchmark jobs, use official benchmark containers/runners where supported. Kaggle's notebook environment may not provide Docker, so run official containerized Terminal-Bench on a suitable CPU host while pointing only the model endpoint to Kaggle. Do not expose shell execution through the public internet.

## H. Train separately, in order

### 1. Freeze the baseline first

Run the base Q4 model on your development tasks and save `outputs/baseline/report.json`. Do not use official Terminal-Bench/DeepSWE tasks for trajectory collection or tuning. The baseline is what every adapter must beat under the same model quant, prompt, budget, and seed set.

### 2. Build permitted training tasks

Use real repositories with licenses that permit this use. Record the repository URL, commit, license, task source, and test command. Bake each repository and its dependencies into a training-task Docker image; the sandbox intentionally has no network or host mounts. Use a verifier such as `pytest -q` that really exercises the requested change. Start with small bug fixes and clear tests, not an entire Minecraft clone.

### 3. Collect verified trajectories

Copy `configs/agent.json` to `configs/train_agent.json`, set your private endpoint and a non-null `verifier`, then run one training task per disposable container:

```bash
proofcoder run 'Fix the parser bug and make the repository tests pass.' \
  --config configs/train_agent.json --image YOUR_TRAINING_TASK_IMAGE
```

Use only training-only tasks. Repeat with fresh tasks/repositories and keep the resulting `runs/*.jsonl` audits. For bulk collection, automate this same one-task-per-container pattern; do not use `run_benchmark.py`, because its provenance deliberately blocks export into training.

### 4. Export and curate the dataset

```bash
PYTHONPATH=src python scripts/export_trajectories.py runs/*.jsonl \
  --repo owner/repository --out data/candidates.jsonl
proofcoder curate data/candidates.jsonl --out data/curated \
  --blocked-repos owner/benchmark-repo-1 owner/benchmark-repo-2
```

When exporting multiple repositories, run the export per repository with its correct `--repo`, then combine the candidate JSONL files before curation. Inspect `data/curated/stats.json` and several samples. Both `train.jsonl` and `validation.jsonl` must be non-empty; use multiple held-out repositories. Reject traces with wrong fixes, weak tests, repeated loops, or huge irrelevant output even if they happen to pass.

### 5. Start with a smoke training run

1. Stop the serving notebook/session. Do not train with llama-server still resident.
2. Create a Kaggle dataset named `proofcoder-data` containing exactly `train.jsonl` and `validation.jsonl` from `data/curated/`.
3. Import `notebooks/kaggle_train.ipynb` into a separate **GPU T4 x2** notebook with Internet on.
4. Replace only `REPO` with your GitHub URL. The official HF model id and immutable commit are already pinned.
5. Choose **Add Data**, attach `proofcoder-data`, and confirm the files appear under `/kaggle/input/proofcoder-data/`.
6. Run cells 1 and 2. Confirm the printed config contains absolute `/kaggle/working/proofcoder/data/curated/...` data paths.
7. For the first run, use a small sample and `epochs=1`. Run the training cell and watch loss, evaluation loss, and peak VRAM. If OOM occurs, set `max_length` to 1024; if needed reduce LoRA rank/targets. Never enable BF16 on T4.
8. Once the smoke run finishes, train the full curated set. Keep the best checkpoint by held-out task results, not training loss alone.
9. The final cell creates `/kaggle/working/proofcoder-adapter.zip`. Download/save it before ending the session; `/kaggle/working` is temporary.

### 6. Merge, quantize, and deploy the adapter

On a high-RAM CPU host (allow roughly 80–128 GB RAM and ample disk for a 27B BF16 merge), run:

```bash
python -m pip install -e '.[train]'
python scripts/merge_adapter.py \
  --adapter outputs/veriloop-e2-proofcoder-lora/final \
  --output outputs/veriloop-e2-proofcoder-merged
python llama.cpp/convert_hf_to_gguf.py outputs/veriloop-e2-proofcoder-merged \
  --outfile outputs/proofcoder-bf16.gguf --outtype bf16
llama.cpp/build/bin/llama-quantize \
  outputs/proofcoder-bf16.gguf outputs/proofcoder-q4_k_m.gguf Q4_K_M
```

Use a current llama.cpp that supports VeriLoop E2. Upload the resulting GGUF to your own Hugging Face repository, then change `HF_REPO_ID`, `HF_GGUF_FILE`, and `HF_REVISION` in the serving notebook to that exact artifact. Rerun development quality, contamination-safe benchmark, and speed evaluations before replacing the base model. Merging and requantizing can regress behavior.

## I. Speed experiments that preserve quality

Run one variable at a time, restart llama-server, and use `scripts/benchmark_speed.py` plus the same coding dev set:

1. `SPLIT_MODE=row` (current default) vs `layer`; `tensor` is experimental.
2. `CTX_SIZE=8192` vs 4096. Smaller context reduces KV memory but can hurt repository tasks.
3. Q8 KV cache (current) vs FP16 KV cache if memory allows; compare quality and speed.
4. `SPEC_TYPE=ngram-simple` for repetitive code. Speculative decoding should preserve outputs under compatible settings, but measure acceptance and actual end-to-end speed.
5. Q4_K_M vs a smaller quant only after measuring coding regression. A faster model that fails more tasks is not better.

Keep a table of median decode tok/s, prompt-processing speed, first-token latency, pass@1, steps, and total wall time. Terminal-Bench measures resolved tasks, not raw tok/s; fewer failed loops and concise verified trajectories often matter more than a small decode-speed gain.

## J. Honest benchmark path

- Establish frozen base Q4 + harness results first.
- Run development tasks while tuning; keep official/test tasks untouched.
- For 64-task internal evaluation, report resolved/64, per-category scores, attempts, timeouts, tokens, and wall time. Three trials mean 192 attempts, not one lucky run.
- Use official Terminal-Bench 4.0 and DeepSWE v1.1 runners for those labels. Their current protocols and scores are not interchangeable with an internal suite.
- Promote an adapter only if paired candidate-minus-baseline improvement holds on fresh tasks and speed remains acceptable. No code in this kit can guarantee 50–55%, 77%, or 30–50 tok/s before measurement.

## K. GPU serving without Kaggle's weekly quota

There is no comparable always-on free 27B GPU service. For paid hourly rental without Kaggle's weekly quota, use:

1. **RunPod Pod with an RTX 5090 32 GB:** simplest first alternative for single-user Q4 inference. Use a persistent volume for the model and llama.cpp, and stop the Pod when not in use.
2. **Vast.ai RTX 5090/4090:** often worth comparing on price, but check host reliability, disk/network speed, and interruptibility before a long run.
3. **A100 80 GB or H100:** choose when you want more VRAM headroom or larger experiments, not because the name alone guarantees better llama.cpp price/performance.
4. **TensorDock:** another hourly marketplace to compare when the above lack capacity.

A 5090/A100-class host is a more plausible route to your 50–100 tok/s goal than two T4s, but actual speed depends on the exact quant, context, KV cache, prompt length, and server build. Measure with `scripts/benchmark_speed.py`; do not buy based on a promised number. Rental is billed by time and storage/egress may cost extra, but there is no Kaggle-style 30-hour weekly training quota on a normal rented VM. Keep the same Tailscale/private-key setup and never expose an unauthenticated model or shell endpoint.
