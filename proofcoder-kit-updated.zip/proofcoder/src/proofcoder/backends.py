"""Backend contract and dependency-free OpenAI-compatible HTTP client."""

from dataclasses import dataclass
import json
import time
from typing import Protocol
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class ChatBackend(Protocol):
    def chat(self, messages: list[dict], *, max_tokens: int, temperature: float, seed: int, timeout_s: float | None = None) -> str: ...


@dataclass
class OpenAICompatibleBackend:
    base_url: str
    model: str
    api_key: str = "EMPTY"
    request_timeout: int = 600
    max_retries: int = 3
    retry_backoff_s: float = 1.0
    chat_template_kwargs: dict | None = None
    last_telemetry: dict | None = None

    def chat(self, messages: list[dict], *, max_tokens: int, temperature: float, seed: int, timeout_s: float | None = None) -> str:
        started = time.perf_counter()
        request_timeout = self.request_timeout if timeout_s is None else max(0.001, min(self.request_timeout, timeout_s))
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "seed": seed,
        }
        if self.chat_template_kwargs:
            payload["chat_template_kwargs"] = self.chat_template_kwargs
        request = Request(
            self.base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
        )
        body = None
        for attempt in range(self.max_retries + 1):
            try:
                attempt_timeout = request_timeout - (time.perf_counter() - started)
                if attempt_timeout <= 0:
                    raise TimeoutError("Backend request exceeded its time budget.")
                with urlopen(request, timeout=attempt_timeout) as response:
                    body = json.load(response)
                break
            except HTTPError as exc:
                if exc.code not in {429, 500, 502, 503, 504} or attempt >= self.max_retries:
                    raise
                remaining = request_timeout - (time.perf_counter() - started)
                if remaining <= 0:
                    raise TimeoutError("Backend request exceeded its time budget.")
                time.sleep(min(self.retry_backoff_s * (2 ** attempt), remaining))
            except (URLError, TimeoutError):
                if attempt >= self.max_retries:
                    raise
                remaining = request_timeout - (time.perf_counter() - started)
                if remaining <= 0:
                    raise TimeoutError("Backend request exceeded its time budget.")
                time.sleep(min(self.retry_backoff_s * (2 ** attempt), remaining))
        if body is None:
            raise RuntimeError("Backend failed without a response.")
        content = body["choices"][0]["message"]["content"]
        elapsed = time.perf_counter() - started
        usage = body.get("usage", {})
        completion_tokens = usage.get("completion_tokens", 0)
        self.last_telemetry = {**usage, "seconds": elapsed, "decode_tokens_per_second": completion_tokens / elapsed if completion_tokens else None}
        if not isinstance(content, str) or not content.strip():
            raise RuntimeError("Backend returned empty content; check chat template and stop tokens.")
        return content
