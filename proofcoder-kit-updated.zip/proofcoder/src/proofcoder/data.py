"""Reject unverified, contaminated, duplicated, and low-quality SFT trajectories."""

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import random
from typing import Iterable
import re

from .protocol import parse_action


def _task_text(row: dict) -> str:
    for message in row.get("messages", []):
        if message.get("role") == "user":
            return message.get("content", "")
    return ""


def task_simhash(row: dict) -> int:
    """64-bit near-duplicate signature; digits/paths are normalized to avoid trivial variants."""
    text = re.sub(r"\d+", "#", _task_text(row).lower())
    tokens = re.findall(r"[a-z_#]+", text)
    shingles = tokens if len(tokens) < 5 else [" ".join(tokens[i:i + 5]) for i in range(len(tokens) - 4)]
    vector = [0] * 64
    for shingle in shingles:
        digest = int.from_bytes(hashlib.sha256(shingle.encode()).digest()[:8], "big")
        for bit in range(64):
            vector[bit] += 1 if digest & (1 << bit) else -1
    return sum((1 << bit) for bit, value in enumerate(vector) if value >= 0)


def preference_pairs(rows: Iterable[dict], blocked_repos: set[str]) -> list[dict]:
    """Same-task verified winner vs near-miss loser; never pair across tasks."""
    grouped = defaultdict(list)
    for row in rows:
        if row.get("repo") in blocked_repos or row.get("benchmark_source"):
            continue
        grouped[row.get("task_id")].append(row)
    pairs = []
    for task_id, candidates in grouped.items():
        winners = [r for r in candidates if trajectory_quality(r)["accepted"]]
        losers = [r for r in candidates if r.get("tests_passed") is False and any("<bash>" in m.get("content", "") for m in r.get("messages", []) if m.get("role") == "assistant")]
        if not winners or not losers:
            continue
        winner = min(winners, key=lambda r: (len(r["messages"]), len(json.dumps(r["messages"]))))
        loser = min(losers, key=lambda r: abs(len(r["messages"]) - len(winner["messages"])))
        if not winner["messages"] or winner["messages"][-1].get("role") != "assistant" or loser["messages"][-1].get("role") != "assistant":
            continue
        # Preserve the shared system+task prefix (or task only); later actions differ.
        prompt_length = 2 if len(winner["messages"]) > 1 and winner["messages"][0].get("role") == "system" and winner["messages"][1].get("role") == "user" else 1
        prompt = winner["messages"][:prompt_length]
        if loser["messages"][:prompt_length] != prompt:
            continue
        pairs.append({"task_id": task_id, "repo": winner["repo"], "prompt": prompt, "chosen": winner["messages"][prompt_length:], "rejected": loser["messages"][prompt_length:]})
    return pairs


def read_jsonl(path: str) -> Iterable[dict]:
    with Path(path).open(encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_line"] = line_no
                yield row


def action_fingerprint(row: dict) -> str:
    actions = [m.get("content", "") for m in row.get("messages", []) if m.get("role") == "assistant"]
    return hashlib.sha256("\n".join(actions).encode()).hexdigest()


def trajectory_quality(row: dict, max_actions: int = 80, max_command_repeats: int = 3, max_example_chars: int = 180000) -> dict:
    """Deterministic hard gates plus a concision score; never grades model claims."""
    reasons = []
    messages = row.get("messages")
    if not isinstance(messages, list) or not messages or messages[-1].get("role") != "assistant":
        return {"accepted": False, "score": 0.0, "reasons": ["bad_message_order"]}
    if row.get("verified") is not True or row.get("tests_passed") is not True:
        reasons.append("unverified")
    verification = row.get("final_verification")
    if not isinstance(verification, dict) or verification.get("returncode") != 0 or verification.get("timed_out"):
        reasons.append("missing_final_verification")
    if row.get("protocol_errors", 0) or any("<protocol_error>" in m.get("content", "") for m in messages):
        reasons.append("protocol_error_leakage")

    actions = []
    for message in messages:
        if message.get("role") != "assistant":
            continue
        try:
            actions.append(parse_action(message.get("content", "")))
        except (TypeError, ValueError):
            reasons.append("invalid_action")
    if not actions or actions[-1].kind != "done" or messages[-1].get("role") != "assistant":
        reasons.append("bad_final_action")
    commands = [action.content.strip() for action in actions if action.kind == "bash"]
    if not commands:
        reasons.append("no_actions")
    if not any(m.get("role") == "user" and 'exit="0"' in m.get("content", "") for m in messages):
        reasons.append("no_success_evidence")

    command_counts = Counter(commands)
    if command_counts and max(command_counts.values()) > max_command_repeats:
        reasons.append("repeated_command")
    if len(actions) > max_actions:
        reasons.append("too_many_actions")
    character_count = len(json.dumps(messages, ensure_ascii=False))
    if character_count > max_example_chars:
        reasons.append("too_long")

    excess_repeats = sum(max(0, count - 1) for count in command_counts.values())
    score = max(0.0, 1.0 - 0.25 * len(actions) / max(1, max_actions) - 0.25 * character_count / max(1, max_example_chars) - 0.1 * excess_repeats)
    return {"accepted": not reasons, "score": round(score, 6), "reasons": list(dict.fromkeys(reasons))}


def valid_row(row: dict, blocked_repos: set[str]) -> tuple[bool, str]:
    required = {"task_id", "repo", "messages", "verified", "tests_passed"}
    if not required.issubset(row):
        return False, "missing_fields"
    if row["repo"] in blocked_repos or row.get("benchmark_source"):
        return False, "contamination"
    quality = trajectory_quality(
        row,
        max_actions=row.get("max_actions", 80),
        max_command_repeats=row.get("max_command_repeats", 3),
        max_example_chars=row.get("max_example_chars", 180000),
    )
    return (True, "accepted") if quality["accepted"] else (False, quality["reasons"][0])


def curate(rows: Iterable[dict], blocked_repos: set[str], max_per_repo: int = 200, val_fraction: float = 0.05, seed: int = 17):
    """Group split by repository: near-duplicate issues cannot cross train/validation."""
    accepted, rejected, seen = [], Counter(), set()
    signatures = []
    per_repo = Counter()
    for row in rows:
        ok, reason = valid_row(row, blocked_repos)
        if not ok:
            rejected[reason] += 1
            continue
        fingerprint = action_fingerprint(row)
        if fingerprint in seen:
            rejected["duplicate"] += 1
            continue
        if per_repo[row["repo"]] >= max_per_repo:
            rejected["repo_cap"] += 1
            continue
        signature = task_simhash(row)
        if any((signature ^ previous).bit_count() <= 3 for previous in signatures):
            rejected["near_duplicate_task"] += 1
            continue
        seen.add(fingerprint)
        signatures.append(signature)
        per_repo[row["repo"]] += 1
        row.pop("_line", None)
        row["quality_score"] = trajectory_quality(row)["score"]
        accepted.append(row)
    repos = sorted({r["repo"] for r in accepted})
    random.Random(seed).shuffle(repos)
    val_target = max(1, round(len(repos) * val_fraction)) if len(repos) > 1 else 0
    val_repos = set(repos[:val_target])
    train = [r for r in accepted if r["repo"] not in val_repos]
    val = [r for r in accepted if r["repo"] in val_repos]
    stats = {"accepted": len(accepted), "train": len(train), "validation": len(val), "rejected": dict(rejected)}
    return train, val, stats


def write_jsonl(path: str, rows: Iterable[dict]) -> None:
    with Path(path).open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
