"""Linear agent loop with verification, budgets, recovery, and full audit logs."""

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from typing import Optional
import uuid

from .backends import ChatBackend
from .protocol import observation_text, parse_action
from .sandbox import LocalEnvironment, Observation

SYSTEM_PROMPT = """You are a coding agent. Work by evidence, not guesses.
Inspect before editing. Make the smallest complete change. Run relevant tests after edits; diagnose failures instead of randomly retrying. Do not claim success without execution evidence.
For web apps, produce a runnable app, check JavaScript syntax and browser console, render it, and exercise core input. No placeholders or fake functionality.
Return exactly one action and no other text:
<bash>one shell command</bash>
or, only after verification passes:
<done>concise result and tests run</done>
Commands run independently; use absolute paths or cd each time. Do not use interactive commands."""


@dataclass
class AgentConfig:
    max_steps: int = 60
    max_tokens: int = 1024
    temperature: float = 0.2
    seed: int = 7
    command_timeout: int = 120
    max_history_chars: int = 60000
    verifier: Optional[str] = None
    repeat_limit: int = 3
    max_wall_time_s: int = 7200
    max_protocol_errors: int = 3
    no_progress_limit: int = 3


@dataclass
class AgentResult:
    resolved: bool
    reason: str
    steps: int
    trajectory_path: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    wall_time_s: float = 0.0
    tool_calls: int = 0
    protocol_errors: int = 0
    command_timeouts: int = 0


class CodingAgent:
    def __init__(self, model: ChatBackend, environment=None, config: Optional[AgentConfig] = None, run_dir: str = "runs", run_metadata: Optional[dict] = None):
        self.model = model
        self.environment = environment or LocalEnvironment(".")
        self.config = config or AgentConfig()
        self.run_dir = Path(run_dir)
        self.run_metadata = run_metadata or {}

    def _trim(self, messages: list[dict]) -> list[dict]:
        """Deterministic compaction: keep instructions, task, latest state, recent turns."""
        total = sum(len(m["content"]) for m in messages)
        if total <= self.config.max_history_chars:
            return messages
        fixed = messages[:2]
        state = {"role": "user", "content": "<checkpoint>Older turns omitted. Reinspect current state.</checkpoint>"}
        recent: list[dict] = []
        used = sum(len(m["content"]) for m in fixed) + len(state["content"])
        for message in reversed(messages[2:]):
            if used + len(message["content"]) > self.config.max_history_chars:
                break
            recent.insert(0, message)
            used += len(message["content"])
        return fixed + [state] + recent

    def _verify(self, remaining_s: float) -> Observation:
        if not self.config.verifier:
            return Observation(1, "No external verifier configured; completion is unverified.", 0.0)
        return self.environment.run(self.config.verifier, max(0.001, min(self.config.command_timeout, remaining_s)))

    def run(self, task: str) -> AgentResult:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        digest = hashlib.sha256(task.encode()).hexdigest()[:8]
        self.run_dir.mkdir(parents=True, exist_ok=True)
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": task}]
        counts: dict[str, int] = {}
        failure_signatures: dict[str, int] = {}
        protocol_errors = 0
        total_protocol_errors = 0
        command_timeouts = 0
        prompt_tokens = 0
        completion_tokens = 0
        tool_calls = 0
        started = time.monotonic()
        resolved, reason = False, "step_budget"

        for _ in range(100):
            path = self.run_dir / f"{stamp}-{digest}-{uuid.uuid4().hex}.jsonl"
            try:
                audit = path.open("x", encoding="utf-8")
                break
            except FileExistsError:
                continue
        else:
            raise RuntimeError("Could not allocate a unique audit path.")
        with audit:
            def record(event: dict) -> None:
                audit.write(json.dumps({"config": asdict(self.config), **self.run_metadata, **event}, ensure_ascii=False) + "\n")
                audit.flush()

            record({"type": "task", "task": task, "system_prompt": SYSTEM_PROMPT})
            for step in range(1, self.config.max_steps + 1):
                remaining_s = self.config.max_wall_time_s - (time.monotonic() - started)
                if remaining_s <= 0:
                    reason = "wall_time_budget"
                    break
                try:
                    reply = self.model.chat(
                        self._trim(messages), max_tokens=self.config.max_tokens,
                        temperature=self.config.temperature, seed=self.config.seed + step - 1,
                        timeout_s=remaining_s,
                    )
                except Exception as exc:
                    reason = "backend_error"
                    record({"type": "backend_error", "step": step, "content": str(exc)})
                    break
                telemetry = getattr(self.model, "last_telemetry", None) or {}
                prompt_tokens += telemetry.get("prompt_tokens", 0) or 0
                completion_tokens += telemetry.get("completion_tokens", 0) or 0
                record({"type": "assistant", "step": step, "content": reply, "telemetry": telemetry or None})
                messages.append({"role": "assistant", "content": reply})
                try:
                    action = parse_action(reply)
                except (TypeError, ValueError) as exc:
                    protocol_errors += 1
                    total_protocol_errors += 1
                    feedback = f"<protocol_error>{exc}</protocol_error>"
                    record({"type": "protocol_error", "step": step, "content": str(exc)})
                    messages.append({"role": "user", "content": feedback})
                    if protocol_errors >= self.config.max_protocol_errors:
                        reason = "protocol_error_budget"
                        break
                    continue
                protocol_errors = 0

                if action.kind == "done":
                    remaining_s = self.config.max_wall_time_s - (time.monotonic() - started)
                    if remaining_s <= 0:
                        reason = "wall_time_budget"
                        break
                    verification = self._verify(remaining_s)
                    command_timeouts += int(verification.timed_out)
                    record({"type": "verify", "step": step, "observation": asdict(verification)})
                    if not self.config.verifier:
                        reason = "unverified"
                        break
                    if self.config.max_wall_time_s - (time.monotonic() - started) <= 0:
                        reason = "wall_time_budget"
                        break
                    if verification.returncode == 0:
                        resolved, reason = True, "verified"
                        messages.append({"role": "user", "content": observation_text(verification.returncode, verification.output, verification.duration_s)})
                        break
                    feedback = observation_text(verification.returncode, "Final verification failed; continue fixing.\n" + verification.output, verification.duration_s)
                    messages.append({"role": "user", "content": feedback})
                    continue

                command = action.content.strip()
                counts[command] = counts.get(command, 0) + 1
                if counts[command] > self.config.repeat_limit:
                    reason = "repeated_command"
                    break
                remaining_s = self.config.max_wall_time_s - (time.monotonic() - started)
                if remaining_s <= 0:
                    reason = "wall_time_budget"
                    break
                observation = self.environment.run(command, max(0.001, min(self.config.command_timeout, remaining_s)))
                tool_calls += 1
                command_timeouts += int(observation.timed_out)
                record({"type": "observation", "step": step, "command": command, "observation": asdict(observation)})
                if self.config.max_wall_time_s - (time.monotonic() - started) <= 0:
                    reason = "wall_time_budget"
                    break
                if observation.returncode != 0:
                    signature = hashlib.sha256((command + "\n" + observation.output).encode()).hexdigest()
                    failure_signatures[signature] = failure_signatures.get(signature, 0) + 1
                    if failure_signatures[signature] >= self.config.no_progress_limit:
                        reason = "no_progress"
                        break
                messages.append({"role": "user", "content": observation_text(observation.returncode, observation.output, observation.duration_s)})
            record({"type": "result", "resolved": resolved, "reason": reason})
        return AgentResult(
            resolved, reason, step if self.config.max_steps else 0, str(path),
            prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
            wall_time_s=time.monotonic() - started, tool_calls=tool_calls,
            protocol_errors=total_protocol_errors, command_timeouts=command_timeouts,
        )
