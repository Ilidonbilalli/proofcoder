"""Frozen-protocol evaluation and uncertainty reporting."""

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class Score:
    resolved: int
    total: int
    pass_rate: float
    wilson_low: float
    wilson_high: float


def wilson_interval(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total == 0:
        return 0.0, 0.0
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    margin = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return center - margin, center + margin


def summarize(results: list[dict]) -> dict:
    successes = sum(bool(r.get("resolved")) for r in results)
    low, high = wilson_interval(successes, len(results))
    by_task: dict[str, list[bool]] = {}
    for result in results:
        by_task.setdefault(result["task_id"], []).append(bool(result.get("resolved")))
    pass_at_k = sum(any(v) for v in by_task.values()) / max(1, len(by_task))
    categories = sorted({r.get("category", "uncategorized") for r in results})
    by_category = {}
    for category in categories:
        subset = [r for r in results if r.get("category", "uncategorized") == category]
        by_category[category] = {"attempts": len(subset), "pass_at_1": sum(bool(r.get("resolved")) for r in subset) / len(subset)}
    count = max(1, len(results))
    prompt_tokens = sum(r.get("prompt_tokens", 0) or 0 for r in results)
    completion_tokens = sum(r.get("completion_tokens", 0) or 0 for r in results)
    wall_time_s = sum(r.get("wall_time_s", 0.0) or 0.0 for r in results)
    tool_calls = sum(r.get("tool_calls", 0) or 0 for r in results)
    protocol_errors = sum(r.get("protocol_errors", 0) or 0 for r in results)
    command_timeouts = sum(r.get("command_timeouts", 0) or 0 for r in results)
    return {
        "attempts": len(results), "tasks": len(by_task), "resolved": successes,
        "pass_at_1": successes / max(1, len(results)), "pass_at_k_any": pass_at_k,
        "wilson_95": [low, high], "by_category": by_category,
        "mean_steps": sum(r.get("steps", 0) for r in results) / count,
        "timeouts": sum(r.get("reason") in {"timeout", "wall_time_budget"} for r in results),
        "total_prompt_tokens": prompt_tokens, "mean_prompt_tokens": prompt_tokens / count,
        "total_completion_tokens": completion_tokens, "mean_completion_tokens": completion_tokens / count,
        "total_tokens": prompt_tokens + completion_tokens,
        "total_wall_time_s": wall_time_s, "mean_wall_time_s": wall_time_s / count,
        "total_tool_calls": tool_calls, "mean_tool_calls": tool_calls / count,
        "total_protocol_errors": protocol_errors, "mean_protocol_errors": protocol_errors / count,
        "command_timeouts": command_timeouts,
    }


def run_identity(metadata: dict) -> str:
    """Identify reusable attempts independently of the requested number of trials."""
    identity = {k: v for k, v in metadata.items() if k != "trials_per_task"}
    canonical = json.dumps(identity, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canonical.encode()).hexdigest()


def _attempt_key(row: dict) -> tuple[str, int]:
    task_id = row.get("task_id")
    trial = row.get("trial")
    if not isinstance(task_id, str) or not task_id or isinstance(trial, bool) or not isinstance(trial, int) or trial < 0:
        raise ValueError("Each result needs a non-empty task_id and a non-negative integer trial.")
    return task_id, trial


def load_resume_results(path: str, identity: str) -> list[dict]:
    """Load only unambiguous rows from the exact same frozen run."""
    source = Path(path)
    if not source.exists():
        return []
    results = []
    seen = set()
    with source.open(encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Malformed resume JSON at line {line_no}: {exc.msg}") from exc
            if not isinstance(row, dict) or row.get("run_id") != identity:
                raise ValueError(f"Resume row {line_no} belongs to a different run configuration.")
            key = _attempt_key(row)
            if key in seen:
                raise ValueError(f"Duplicate completed attempt: {key[0]} trial {key[1]}.")
            seen.add(key)
            results.append(row)
    return results


def remaining_trials(tasks: list[dict], trials: int, existing: list[dict]) -> list[tuple[dict, int]]:
    """Plan only missing attempts; existing extra trials remain in the final report."""
    if trials < 1:
        raise ValueError("trials must be at least 1")
    completed = {_attempt_key(row) for row in existing}
    return [(task, trial) for task in tasks for trial in range(trials) if (task["task_id"], trial) not in completed]


def classify_failure(reason: str) -> str:
    if reason in {"step_budget", "wall_time_budget"}:
        return "budget"
    if reason in {"no_progress", "repeated_command"}:
        return "recovery"
    if reason in {"protocol_error_budget", "backend_error"}:
        return "protocol"
    if reason == "timeout":
        return "environment"
    return "unknown"


def compare_runs(baseline: list[dict], candidate: list[dict]) -> dict:
    """Paired task/trial comparison; unmatched attempts are reported, never silently dropped."""
    def keyed(rows):
        keyed_rows = {}
        for row in rows:
            key = _attempt_key(row)
            if key in keyed_rows:
                raise ValueError(f"Duplicate comparison attempt: {key[0]} trial {key[1]}.")
            keyed_rows[key] = bool(row.get("resolved"))
        return keyed_rows
    base, new = keyed(baseline), keyed(candidate)
    shared = sorted(base.keys() & new.keys())
    wins = sum(new[k] and not base[k] for k in shared)
    losses = sum(base[k] and not new[k] for k in shared)
    base_rate = sum(base[k] for k in shared) / max(1, len(shared))
    new_rate = sum(new[k] for k in shared) / max(1, len(shared))
    return {"paired_attempts": len(shared), "baseline_pass_at_1": base_rate, "candidate_pass_at_1": new_rate, "delta": new_rate - base_rate, "candidate_only_wins": wins, "candidate_only_losses": losses, "unmatched_baseline": len(base.keys() - new.keys()), "unmatched_candidate": len(new.keys() - base.keys())}


def write_report(path: str, metadata: dict, results: list[dict], immutable: bool = False) -> None:
    """Write one complete report; immutable mode refuses to overwrite a finalized run."""
    report = {"metadata": metadata, "metrics": summarize(results), "results": results}
    with Path(path).open("x" if immutable else "w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2)
        handle.write("\n")
