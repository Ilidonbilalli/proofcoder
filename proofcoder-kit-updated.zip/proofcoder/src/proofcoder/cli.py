"""Command-line entry points; no mandatory third-party runtime dependencies."""

import argparse
import json
import os
from pathlib import Path

from .backends import OpenAICompatibleBackend
from .data import curate, preference_pairs, read_jsonl, write_jsonl
from .evaluate import summarize
from .harness import AgentConfig, CodingAgent
from .sandbox import DockerEnvironment, LocalEnvironment
from .webverify import verify


def main() -> None:
    parser = argparse.ArgumentParser(prog="proofcoder")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="Run one coding task")
    run.add_argument("task")
    run.add_argument("--config", default="configs/agent.json")
    run.add_argument("--local", action="store_true", help="Unsafe for untrusted code; use Docker instead")
    run.add_argument("--image", default="python:3.12-slim")

    curate_parser = sub.add_parser("curate", help="Filter and group-split JSONL trajectories")
    curate_parser.add_argument("input")
    curate_parser.add_argument("--out", default="data/curated")
    curate_parser.add_argument("--blocked-repos", nargs="*", default=[])
    curate_parser.add_argument("--max-per-repo", type=int, default=200)

    prefs = sub.add_parser("preferences", help="Build same-task verified preference pairs")
    prefs.add_argument("input")
    prefs.add_argument("--out", default="data/preferences.jsonl")
    prefs.add_argument("--blocked-repos", nargs="*", default=[])

    score = sub.add_parser("score", help="Summarize result JSONL")
    score.add_argument("results")

    web = sub.add_parser("web-check", help="Run static and optional browser checks")
    web.add_argument("root")
    web.add_argument("--url")
    web.add_argument("--game", action="store_true")
    web.add_argument("--screenshot", default="artifacts/web.png")

    args = parser.parse_args()
    if args.command == "run":
        raw = json.loads(Path(args.config).read_text(encoding="utf-8"))
        model = OpenAICompatibleBackend(
            raw["base_url"], raw["model"],
            api_key=raw.get("api_key") or os.environ.get("PROOFCODER_API_KEY", "EMPTY"),
            chat_template_kwargs=raw.get("chat_template_kwargs"),
        )
        fields = {k: v for k, v in raw.items() if k in AgentConfig.__dataclass_fields__}
        environment = LocalEnvironment(raw["workdir"]) if args.local else DockerEnvironment(args.image)
        try:
            result = CodingAgent(model, environment, AgentConfig(**fields)).run(args.task)
            print(json.dumps(result.__dict__, indent=2))
        finally:
            if hasattr(environment, "close"):
                environment.close()
    elif args.command == "curate":
        train, val, stats = curate(read_jsonl(args.input), set(args.blocked_repos), args.max_per_repo)
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        write_jsonl(str(out / "train.jsonl"), train)
        write_jsonl(str(out / "validation.jsonl"), val)
        (out / "stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
        print(json.dumps(stats, indent=2))
    elif args.command == "preferences":
        pairs = preference_pairs(read_jsonl(args.input), set(args.blocked_repos))
        write_jsonl(args.out, pairs)
        print(json.dumps({"preference_pairs": len(pairs), "output": args.out}, indent=2))
    elif args.command == "score":
        print(json.dumps(summarize(list(read_jsonl(args.results))), indent=2))
    elif args.command == "web-check":
        report = verify(args.root, args.url, args.screenshot, args.game)
        print(json.dumps(report, indent=2))
        raise SystemExit(0 if report["passed"] else 1)
