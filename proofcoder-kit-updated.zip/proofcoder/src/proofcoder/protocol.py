"""Tiny text protocol: easy for quantized models and exact for training."""

from dataclasses import dataclass
import re

BASH_RE = re.compile(r"<bash>\s*(.*?)\s*</bash>", re.DOTALL | re.IGNORECASE)
DONE_RE = re.compile(r"<done>\s*(.*?)\s*</done>", re.DOTALL | re.IGNORECASE)


@dataclass(frozen=True)
class Action:
    kind: str
    content: str


def parse_action(text: str) -> Action:
    """Require exactly one complete action; reject ambiguous multi-actions."""
    actions = [(m.start(), Action("bash", m.group(1))) for m in BASH_RE.finditer(text)]
    actions += [(m.start(), Action("done", m.group(1))) for m in DONE_RE.finditer(text)]
    if len(actions) != 1:
        raise ValueError("Emit exactly one <bash>...</bash> or <done>...</done> action.")
    action = actions[0][1]
    if not action.content.strip():
        raise ValueError("The action is empty.")
    # Text outside the envelope is usually a reasoning leak or two attempted answers.
    outside = BASH_RE.sub("", DONE_RE.sub("", text)).strip()
    if outside:
        raise ValueError("Do not put prose outside the action envelope.")
    return action


def observation_text(returncode: int, output: str, duration_s: float) -> str:
    return f"<observation exit=\"{returncode}\" seconds=\"{duration_s:.2f}\">\n{output}\n</observation>"
