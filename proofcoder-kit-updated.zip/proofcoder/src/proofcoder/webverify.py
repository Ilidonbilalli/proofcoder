"""Static and real-browser gates for generated web applications and games."""

from html.parser import HTMLParser
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


class AppParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.references: list[str] = []
        self.inline_scripts: list[str] = []
        self._in_script = False
        self.canvas_count = 0

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "script":
            self._in_script = True
            if values.get("src"):
                self.references.append(values["src"])
        if tag == "link" and values.get("href"):
            self.references.append(values["href"])
        if tag in {"img", "source"} and values.get("src"):
            self.references.append(values["src"])
        if tag == "canvas":
            self.canvas_count += 1

    def handle_endtag(self, tag):
        if tag == "script":
            self._in_script = False

    def handle_data(self, data):
        if self._in_script:
            self.inline_scripts.append(data)


def _is_local(reference: str) -> bool:
    return not reference.startswith(("http://", "https://", "//", "data:", "blob:", "#"))


def static_check(root: str, entry: str = "index.html", require_canvas: bool = False) -> dict:
    root_path = Path(root).resolve()
    entry_path = (root_path / entry).resolve()
    errors = []
    if root_path not in entry_path.parents or not entry_path.is_file():
        return {"passed": False, "errors": ["Missing or unsafe HTML entry: " + entry]}
    parser = AppParser()
    parser.feed(entry_path.read_text(encoding="utf-8", errors="replace"))
    if require_canvas and parser.canvas_count == 0:
        errors.append("Game check requires a real <canvas>.")
    local_assets = []
    for reference in parser.references:
        if _is_local(reference):
            asset = (entry_path.parent / reference.split("?")[0]).resolve()
            if root_path not in asset.parents:
                errors.append("Asset escapes app root: " + reference)
            elif not asset.is_file():
                errors.append("Missing local asset: " + reference)
            else:
                local_assets.append(asset)
    node = shutil.which("node")
    if node:
        scripts = [asset.read_text(encoding="utf-8") for asset in local_assets if asset.suffix == ".js"]
        scripts += parser.inline_scripts
        for index, source in enumerate(scripts):
            with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as handle:
                handle.write(source)
                temp_path = handle.name
            result = subprocess.run([node, "--check", temp_path], capture_output=True, text=True)
            Path(temp_path).unlink(missing_ok=True)
            if result.returncode:
                errors.append(f"JavaScript syntax error in script {index}: {result.stderr[-1500:]}")
    else:
        errors.append("Node.js is required for JavaScript syntax verification.")
    return {"passed": not errors, "errors": errors, "scripts": len(parser.inline_scripts), "canvas": parser.canvas_count}


def browser_check(url: str, screenshot_path: str, game: bool = False) -> dict:
    """Requires: pip install playwright && playwright install chromium."""
    from playwright.sync_api import sync_playwright

    errors, console = [], []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 1280, "height": 720})
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.on("console", lambda message: console.append(f"{message.type}: {message.text}") if message.type == "error" else None)
        response = page.goto(url, wait_until="networkidle", timeout=30000)
        if response and response.status >= 400:
            errors.append(f"HTTP {response.status}")
        page.screenshot(path=screenshot_path, full_page=True)
        before = hashlib.sha256(Path(screenshot_path).read_bytes()).hexdigest()
        if game:
            if page.locator("canvas").count() == 0:
                errors.append("No canvas in browser DOM.")
            else:
                page.locator("canvas").first.click(position={"x": 100, "y": 100})
                page.keyboard.down("ArrowRight")
                page.wait_for_timeout(500)
                page.keyboard.up("ArrowRight")
                page.wait_for_timeout(250)
                after_path = str(Path(screenshot_path).with_name("after-input.png"))
                page.screenshot(path=after_path, full_page=True)
                after = hashlib.sha256(Path(after_path).read_bytes()).hexdigest()
                if before == after:
                    errors.append("Screenshot did not change after keyboard input; add task-specific behavioral tests.")
        browser.close()
    errors += ["Browser console: " + message for message in console]
    return {"passed": not errors, "errors": errors, "screenshot": screenshot_path}


def verify(root: str, url: str | None = None, screenshot: str = "artifacts/web.png", game: bool = False) -> dict:
    static = static_check(root, require_canvas=game)
    if not static["passed"] or not url:
        return {"passed": static["passed"] and bool(url) is False, "static": static, "browser": None}
    Path(screenshot).parent.mkdir(parents=True, exist_ok=True)
    browser = browser_check(url, screenshot, game)
    return {"passed": static["passed"] and browser["passed"], "static": static, "browser": browser}
