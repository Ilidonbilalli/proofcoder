"""Execution environments. Docker is the safe default for untrusted trajectories."""

from dataclasses import dataclass
import os
from pathlib import Path
import shlex
import subprocess
import time


def _text(value) -> str:
    if isinstance(value, bytes):
        return value.decode(errors="replace")
    return value or ""


@dataclass(frozen=True)
class Observation:
    returncode: int
    output: str
    duration_s: float
    timed_out: bool = False


def compact_output(text: str, limit: int = 12000) -> str:
    """Keep both ends: errors often live at the end, context at the beginning."""
    if len(text) <= limit:
        return text or "(no output)"
    head = limit * 2 // 3
    tail = limit - head
    return f"{text[:head]}\n...[truncated {len(text) - limit} chars]...\n{text[-tail:]}"


class LocalEnvironment:
    """Development only. Commands have the current user's permissions."""

    def __init__(self, workdir: str, output_limit: int = 12000):
        self.workdir = str(Path(workdir).resolve())
        self.output_limit = output_limit

    def run(self, command: str, timeout: int = 120) -> Observation:
        started = time.monotonic()
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.workdir,
                capture_output=True,
                text=True,
                errors="replace",
                timeout=timeout,
                env={**os.environ, "PYTHONUNBUFFERED": "1"},
            )
            output = result.stdout + result.stderr
            return Observation(result.returncode, compact_output(output, self.output_limit), time.monotonic() - started)
        except subprocess.TimeoutExpired as exc:
            output = _text(exc.stdout) + _text(exc.stderr)
            return Observation(124, compact_output(output + "\nTIMEOUT", self.output_limit), time.monotonic() - started, True)


class DockerEnvironment:
    """Disposable container with no host mounts, no network by default, and hard limits."""

    def __init__(self, image: str = "python:3.12-slim", workdir: str = "/tmp/workspace", output_limit: int = 12000):
        self.image = image
        self.workdir = workdir
        self.output_limit = output_limit
        self.name = f"proofcoder-{os.getpid()}-{time.time_ns()}"
        self._start()

    def _start(self) -> None:
        command = [
            "docker", "run", "-d", "--name", self.name,
            "--network", "none", "--cpus", "2", "--memory", "4g",
            "--pids-limit", "256", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--user", "65534:65534",
            "--workdir", self.workdir, self.image, "sleep", "infinity",
        ]
        subprocess.run(command, check=True, capture_output=True, text=True)

    def run(self, command: str, timeout: int = 120) -> Observation:
        started = time.monotonic()
        wrapped = f"mkdir -p {shlex.quote(self.workdir)} && cd {shlex.quote(self.workdir)} && {command}"
        try:
            result = subprocess.run(
                ["docker", "exec", self.name, "sh", "-lc", wrapped],
                capture_output=True, text=True, errors="replace", timeout=timeout,
            )
            output = result.stdout + result.stderr
            return Observation(result.returncode, compact_output(output, self.output_limit), time.monotonic() - started)
        except subprocess.TimeoutExpired as exc:
            output = _text(exc.stdout) + _text(exc.stderr)
            return Observation(124, compact_output(output + "\nTIMEOUT", self.output_limit), time.monotonic() - started, True)

    def close(self) -> None:
        subprocess.run(["docker", "rm", "-f", self.name], capture_output=True)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
