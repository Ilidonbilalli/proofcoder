"""ProofCoder: a small, auditable coding-agent harness."""

from .backends import ChatBackend, OpenAICompatibleBackend
from .harness import AgentConfig, CodingAgent
from .sandbox import DockerEnvironment, LocalEnvironment

__all__ = [
    "AgentConfig",
    "ChatBackend",
    "CodingAgent",
    "DockerEnvironment",
    "LocalEnvironment",
    "OpenAICompatibleBackend",
]
