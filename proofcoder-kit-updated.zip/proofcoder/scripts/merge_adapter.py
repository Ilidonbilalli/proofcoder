"""Merge a trained VeriLoop E2 LoRA adapter on a high-RAM CPU host."""

import argparse
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", default="tsinghua-sigs-robot-lab/VeriLoop-E2")
    parser.add_argument("--revision", default="44b6f230347f9ccf2a5ce96a44bcd74ecaaaa51f")
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    import torch
    from peft import PeftModel
    from transformers import AutoModelForMultimodalLM, AutoTokenizer

    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite merged model: {output}")
    model = AutoModelForMultimodalLM.from_pretrained(
        args.base_model,
        revision=args.revision,
        torch_dtype=torch.bfloat16,
        device_map="cpu",
        low_cpu_mem_usage=True,
    )
    model = PeftModel.from_pretrained(model, args.adapter)
    merged = model.merge_and_unload()
    output.mkdir(parents=True)
    merged.save_pretrained(output, safe_serialization=True, max_shard_size="4GB")
    tokenizer = AutoTokenizer.from_pretrained(args.base_model, revision=args.revision, use_fast=True)
    tokenizer.save_pretrained(output)
    print(f"Merged BF16 model saved to {output}")


if __name__ == "__main__":
    main()
