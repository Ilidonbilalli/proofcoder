"""27B QLoRA SFT for two T4s. Run separately from inference; data stays on CPU/disk."""

import argparse
import json
from pathlib import Path


def encode_assistant_only(tokenizer, messages: list[dict], max_length: int) -> dict:
    """Build role-aware assistant masks without requiring {% generation %} markers."""
    rendered = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False, enable_thinking=False)
    input_ids = tokenizer(rendered, add_special_tokens=False)["input_ids"]
    labels = [-100] * len(input_ids)
    spans = 0
    for index, message in enumerate(messages):
        if message.get("role") != "assistant":
            continue
        prefix = tokenizer.apply_chat_template(
            messages[:index], tokenize=False, add_generation_prompt=True, enable_thinking=False,
        )
        through_assistant = tokenizer.apply_chat_template(
            messages[:index + 1], tokenize=False, add_generation_prompt=False, enable_thinking=False,
        )
        if not rendered.startswith(prefix) or not rendered.startswith(through_assistant) or len(prefix) >= len(through_assistant):
            raise ValueError("Chat template prefixes are inconsistent; refusing to guess assistant loss spans.")
        prefix_ids = tokenizer(prefix, add_special_tokens=False)["input_ids"]
        through_ids = tokenizer(through_assistant, add_special_tokens=False)["input_ids"]
        if through_ids[:len(prefix_ids)] != prefix_ids or input_ids[:len(through_ids)] != through_ids:
            raise ValueError("Tokenization changed across a chat-template boundary; use a boundary-stable tokenizer.")
        labels[len(prefix_ids):len(through_ids)] = input_ids[len(prefix_ids):len(through_ids)]
        spans += 1
    keep = len(input_ids) <= max_length and spans > 0
    return {"input_ids": input_ids, "labels": labels, "attention_mask": [1] * len(input_ids), "_keep": keep}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/qlora_27b_t4.json")
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text())

    import torch
    from datasets import load_dataset
    from peft import LoraConfig, get_peft_model
    from transformers import (
        AutoModelForCausalLM, AutoModelForMultimodalLM, AutoTokenizer,
        BitsAndBytesConfig, Trainer, TrainingArguments,
    )

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPUs not found.")
    for index in range(torch.cuda.device_count()):
        major, minor = torch.cuda.get_device_capability(index)
        print(f"GPU {index}: {torch.cuda.get_device_name(index)}, compute {major}.{minor}")
        if major < 8 and cfg.get("bf16"):
            raise RuntimeError("Turing/T4 does not support BF16; set bf16=false and fp16=true.")

    tokenizer = AutoTokenizer.from_pretrained(cfg["base_model"], revision=cfg.get("model_revision"), use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    quantization = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.float16,
    )
    model_class = AutoModelForCausalLM if cfg.get("model_class") == "causal_lm" else AutoModelForMultimodalLM
    model = model_class.from_pretrained(
        cfg["base_model"], revision=cfg.get("model_revision"), quantization_config=quantization,
        device_map="balanced", torch_dtype=torch.float16,
        attn_implementation=cfg.get("attn_implementation", "eager"),
    )
    model.config.use_cache = False
    lora = LoraConfig(
        r=cfg["lora_r"], lora_alpha=cfg["lora_alpha"], lora_dropout=cfg["lora_dropout"],
        bias="none", task_type="CAUSAL_LM", target_modules=cfg["target_modules"],
    )
    dataset = load_dataset("json", data_files={"train": cfg["train_file"], "validation": cfg["validation_file"]})
    original_counts = {split: len(rows) for split, rows in dataset.items()}
    dataset = dataset.map(
        lambda row: encode_assistant_only(tokenizer, row["messages"], cfg["max_length"]),
        remove_columns=dataset["train"].column_names,
    )
    dataset = dataset.filter(lambda row: row["_keep"]).remove_columns(["_keep"])
    if not len(dataset["train"]) or not len(dataset["validation"]):
        raise RuntimeError(f"Need non-empty train/validation after assistant masking and length filtering: {original_counts}")
    print({"original_rows": original_counts, "usable_rows": {split: len(rows) for split, rows in dataset.items()}})

    def collate(features):
        width = max(len(feature["input_ids"]) for feature in features)
        input_ids, labels, attention = [], [], []
        for feature in features:
            padding = width - len(feature["input_ids"])
            input_ids.append(feature["input_ids"] + [tokenizer.pad_token_id] * padding)
            labels.append(feature["labels"] + [-100] * padding)
            attention.append(feature["attention_mask"] + [0] * padding)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "attention_mask": torch.tensor(attention, dtype=torch.long),
        }

    args = TrainingArguments(
        output_dir=cfg["output_dir"],
        per_device_train_batch_size=1, per_device_eval_batch_size=1,
        gradient_accumulation_steps=cfg["gradient_accumulation_steps"],
        gradient_checkpointing=True, gradient_checkpointing_kwargs={"use_reentrant": False},
        learning_rate=cfg["learning_rate"], lr_scheduler_type="cosine", warmup_ratio=0.03,
        num_train_epochs=cfg["epochs"], logging_steps=5, eval_strategy="steps", eval_steps=50,
        save_steps=50, save_total_limit=3, save_strategy="steps",
        fp16=True, bf16=False, optim="paged_adamw_8bit", report_to=[],
        dataloader_num_workers=0, group_by_length=True, seed=cfg["seed"],
    )
    model = get_peft_model(model, lora)
    trainer = Trainer(model=model, args=args, train_dataset=dataset["train"], eval_dataset=dataset["validation"], data_collator=collate, processing_class=tokenizer)
    trainer.train()
    trainer.save_model(cfg["output_dir"] + "/final")
    tokenizer.save_pretrained(cfg["output_dir"] + "/final")


if __name__ == "__main__":
    main()
