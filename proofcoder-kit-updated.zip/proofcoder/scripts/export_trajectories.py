"""Convert only verifier-passed harness audit logs into SFT rows."""

import argparse
import hashlib
import json
from pathlib import Path



def export(paths, repo: str, include_failed: bool = False):
    for path in paths:
        events = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
        if not events or events[-1].get("type") != "result" or not events[-1].get("config", {}).get("verifier"):
            continue
        resolved = bool(events[-1].get("resolved"))
        if not resolved and not include_failed:
            continue
        task_event = next(e for e in events if e["type"] == "task")
        if not task_event.get("system_prompt"):
            continue
        verify_indices = [i for i, event in enumerate(events) if event["type"] == "verify"]
        final_verify_index = verify_indices[-1] if verify_indices else None
        final_verification = events[final_verify_index]["observation"] if final_verify_index is not None else None
        verification_passed = bool(final_verification and final_verification.get("returncode") == 0 and not final_verification.get("timed_out"))
        if (resolved and not verification_passed) or (final_verification is not None and resolved != verification_passed):
            continue
        protocol_errors = sum(event["type"] == "protocol_error" for event in events)
        messages = [{"role": "system", "content": task_event["system_prompt"]}]
        for index, event in enumerate(events):
            if event["type"] == "task":
                messages.append({"role": "user", "content": event["task"]})
            elif event["type"] == "assistant":
                messages.append({"role": "assistant", "content": event["content"]})
            elif event["type"] == "protocol_error":
                messages.append({"role": "user", "content": f"<protocol_error>{event['content']}</protocol_error>"})
            elif event["type"] in {"observation", "verify"}:
                if resolved and index == final_verify_index and event["observation"]["returncode"] == 0:
                    # The terminal <done> stays final; terminal verification remains structured metadata.
                    continue
                obs = event["observation"]
                content = f"<observation exit=\"{obs['returncode']}\" seconds=\"{obs['duration_s']:.2f}\">\n{obs['output']}\n</observation>"
                messages.append({"role": "user", "content": content})
        while messages and messages[-1]["role"] != "assistant":
            messages.pop()
        if not messages or messages[-1]["role"] != "assistant":
            continue
        yield {
            "task_id": hashlib.sha256(task_event["task"].encode()).hexdigest()[:16], "run_id": Path(path).stem, "repo": repo, "messages": messages,
            "verified": resolved, "tests_passed": resolved, "source_trajectory": str(path),
            "final_verification": final_verification, "protocol_errors": protocol_errors,
            "benchmark_source": task_event.get("benchmark_source"),
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("runs", nargs="+")
    parser.add_argument("--repo", required=True, help="Provenance group; never use a benchmark name here")
    parser.add_argument("--out", default="data/candidates.jsonl")
    parser.add_argument("--include-failed", action="store_true", help="Include externally tested losers for preference pairs, never for SFT")
    args = parser.parse_args()
    with Path(args.out).open("w", encoding="utf-8") as handle:
        for row in export(args.runs, args.repo, args.include_failed):
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
