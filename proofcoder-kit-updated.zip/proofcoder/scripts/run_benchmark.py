"""Sequential runner for a frozen JSONL task manifest (Docker required)."""

import argparse
import hashlib
import json
import os
from pathlib import Path

from proofcoder.backends import OpenAICompatibleBackend
from proofcoder.evaluate import load_resume_results, remaining_trials, run_identity, write_report
from proofcoder.harness import AgentConfig, CodingAgent
from proofcoder.sandbox import DockerEnvironment


def _harness_hash() -> str:
    digest = hashlib.sha256()
    digest.update(Path(__file__).name.encode())
    digest.update(Path(__file__).read_bytes())
    source = Path(__file__).parents[1] / "src" / "proofcoder"
    for path in sorted(source.glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def validate_tasks(tasks: list[dict]) -> None:
    """Reject ambiguous manifests before creating resumable output state."""
    if not tasks:
        raise ValueError("Benchmark manifest contains no tasks.")
    task_ids = [task.get("task_id") for task in tasks]
    if any(not isinstance(task_id, str) or not task_id.strip() for task_id in task_ids):
        raise ValueError("Every benchmark task needs a non-empty string task_id.")
    if len(set(task_ids)) != len(task_ids):
        raise ValueError("Duplicate task_id values would corrupt benchmark resume and reporting.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", help="JSONL: task_id, prompt, image, verifier")
    parser.add_argument("--config", default="configs/agent.json")
    parser.add_argument("--trials", type=int, default=3)
    parser.add_argument("--out", default="outputs/benchmark")
    args = parser.parse_args()
    raw = json.loads(Path(args.config).read_text())
    model = OpenAICompatibleBackend(
        raw["base_url"], raw["model"],
        api_key=raw.get("api_key") or os.environ.get("PROOFCODER_API_KEY", "EMPTY"),
        chat_template_kwargs=raw.get("chat_template_kwargs"),
    )
    tasks = [json.loads(line) for line in Path(args.manifest).read_text().splitlines() if line.strip()]
    validate_tasks(tasks)
    if args.trials < 1:
        parser.error("--trials must be at least 1")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    report_path = out / "report.json"
    if report_path.exists():
        raise FileExistsError(f"Refusing to modify finalized report: {report_path}")
    metadata = {
        "manifest_sha256": hashlib.sha256(Path(args.manifest).read_bytes()).hexdigest(),
        "config_sha256": hashlib.sha256(Path(args.config).read_bytes()).hexdigest(),
        "harness_sha256": _harness_hash(),
        "model": raw["model"],
        "model_revision": raw.get("model_revision", "unspecified"),
        "quantization": raw.get("quantization", "unspecified"),
        "sampling": {k: raw.get(k) for k in ("temperature", "seed", "max_tokens")},
        "budget": {k: raw.get(k) for k in ("max_steps", "command_timeout", "max_wall_time_s")},
        "trials_per_task": args.trials,
    }
    identity = run_identity(metadata)
    metadata["run_id"] = identity
    results_path = out / "results.jsonl"
    results = load_resume_results(str(results_path), identity)
    pending = remaining_trials(tasks, args.trials, results)
    print(json.dumps({"resumed_attempts": len(results), "pending_attempts": len(pending), "run_id": identity}))
    for task, trial in pending:
        environment = DockerEnvironment(task.get("image", "python:3.12-slim"))
        try:
            fields = {k: v for k, v in raw.items() if k in AgentConfig.__dataclass_fields__}
            fields.update(verifier=task["verifier"], seed=raw.get("seed", 7) + trial)
            result = CodingAgent(
                model, environment, AgentConfig(**fields), str(out / "trajectories"),
                run_metadata={"benchmark_source": "manifest:" + metadata["manifest_sha256"], "run_id": identity},
            ).run(task["prompt"])
            row = {"task_id": task["task_id"], "trial": trial, "category": task.get("category", "uncategorized"), "difficulty": task.get("difficulty", "unknown"), "run_id": identity, **result.__dict__}
            results.append(row)
            with results_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(row) + "\n")
            print(json.dumps(row))
        finally:
            environment.close()
    write_report(str(report_path), metadata, results, immutable=True)


if __name__ == "__main__":
    main()
