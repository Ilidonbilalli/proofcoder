#!/usr/bin/env bash
set -euo pipefail
: "${MODEL_PATH:?Set MODEL_PATH to the exact Q4_K_M GGUF file}"
# Inference only. Stop this server before QLoRA training.
EXTRA_ARGS=()
if [[ -n "${SPEC_TYPE:-}" ]]; then
  EXTRA_ARGS+=(--spec-type "$SPEC_TYPE")
fi
exec llama-server \
  --model "$MODEL_PATH" --alias "${MODEL_ALIAS:-veriloop-e2-27b-q4}" \
  --host 127.0.0.1 --port 8000 \
  --n-gpu-layers 999 --tensor-split 1,1 --split-mode "${SPLIT_MODE:-row}" \
  --ctx-size "${CTX_SIZE:-8192}" --parallel 1 \
  --flash-attn --cache-type-k q8_0 --cache-type-v q8_0 \
  --api-key "${LLAMA_API_KEY:?Set a strong LLAMA_API_KEY}" --metrics "${EXTRA_ARGS[@]}"
