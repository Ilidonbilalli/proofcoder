"""Serve a generated app temporarily and run real Chromium checks."""

import argparse
import functools
import http.server
import json
import threading

from proofcoder.webverify import verify


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root")
    parser.add_argument("--game", action="store_true")
    parser.add_argument("--screenshot", default="artifacts/web.png")
    args = parser.parse_args()
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=args.root)
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/index.html"
        report = verify(args.root, url, args.screenshot, args.game)
        print(json.dumps(report, indent=2))
        raise SystemExit(0 if report["passed"] else 1)
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


if __name__ == "__main__":
    main()
