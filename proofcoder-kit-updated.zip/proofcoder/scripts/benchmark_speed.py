"""Measure real decode throughput; never infer tok/s from model size or bandwidth."""

import argparse
import json
import statistics
import time
from urllib.request import Request, urlopen


def request_tokens(args, prompt: str, max_tokens: int) -> dict:
    payload = {"model": args.model, "messages": [{"role": "user", "content": prompt}], "max_tokens": max_tokens, "temperature": 0, "stream": False}
    request = Request(args.base_url.rstrip("/") + "/chat/completions", data=json.dumps(payload).encode(), headers={"Content-Type": "application/json", "Authorization": "Bearer " + args.api_key})
    started = time.perf_counter()
    with urlopen(request, timeout=600) as response:
        body = json.load(response)
    elapsed = time.perf_counter() - started
    usage = body.get("usage", {})
    completion = usage.get("completion_tokens")
    if not completion:
        raise RuntimeError("Server omitted usage.completion_tokens; cannot report honest decode speed.")
    return {"seconds": elapsed, "completion_tokens": completion, "tokens_per_second": completion / elapsed, "prompt_tokens": usage.get("prompt_tokens", 0)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:8000/v1")
    parser.add_argument("--model", required=True)
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--max-tokens", type=int, default=128)
    args = parser.parse_args()
    request_tokens(args, "Reply with OK.", 8)  # warmup, excluded
    prompt = "Implement a Python LRU cache with O(1) get and put. Include type hints and concise tests."
    results = [request_tokens(args, prompt, args.max_tokens) for _ in range(args.runs)]
    speeds = [r["tokens_per_second"] for r in results]
    report = {"runs": results, "median_decode_tokens_per_second": statistics.median(speeds), "min": min(speeds), "max": max(speeds), "note": "End-to-end non-streaming decode rate including HTTP overhead; prompt processing is not decode speed."}
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
