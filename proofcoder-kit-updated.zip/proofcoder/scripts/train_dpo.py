"""Optional second-stage DPO on same-task externally verified preference pairs."""

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/dpo_27b_t4.json")
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text())

    import torch
    from datasets import load_dataset
    from peft import LoraConfig, PeftModel
    from transformers import AutoModelForMultimodalLM, AutoTokenizer, BitsAndBytesConfig
    from trl import DPOConfig, DPOTrainer

    tokenizer = AutoTokenizer.from_pretrained(cfg["base_model"], revision=cfg.get("model_revision"))
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.float16)
    model = AutoModelForMultimodalLM.from_pretrained(
        cfg["base_model"], revision=cfg.get("model_revision"), quantization_config=quant,
        device_map="balanced", torch_dtype=torch.float16, attn_implementation="eager",
    )
    model.config.use_cache = False
    if cfg.get("sft_adapter"):
        model = PeftModel.from_pretrained(model, cfg["sft_adapter"], is_trainable=True)
        peft_config = None
    else:
        peft_config = LoraConfig(r=8, lora_alpha=16, lora_dropout=0.05, target_modules=cfg["target_modules"], task_type="CAUSAL_LM")
    dataset = load_dataset("json", data_files=cfg["preference_file"], split="train")
    args = DPOConfig(
        output_dir=cfg["output_dir"], beta=cfg.get("beta", 0.1),
        max_length=cfg["max_length"], max_prompt_length=cfg["max_prompt_length"],
        per_device_train_batch_size=1, gradient_accumulation_steps=16,
        gradient_checkpointing=True, gradient_checkpointing_kwargs={"use_reentrant": False},
        learning_rate=cfg["learning_rate"], num_train_epochs=1,
        fp16=True, bf16=False, optim="paged_adamw_8bit",
        logging_steps=5, save_steps=50, save_total_limit=2, report_to=[],
        dataset_num_proc=2, seed=17,
    )
    # ref_model=None uses the adapter-disabled policy as reference, avoiding a second 27B copy.
    trainer = DPOTrainer(model=model, ref_model=None, args=args, train_dataset=dataset, processing_class=tokenizer, peft_config=peft_config)
    trainer.train()
    trainer.save_model(cfg["output_dir"] + "/final")
    tokenizer.save_pretrained(cfg["output_dir"] + "/final")


if __name__ == "__main__":
    main()
