# Public-evidence design notes

Research date: 2026-10-27. This kit uses public documentation and papers, not leaked proprietary material. Public benchmark pages sometimes disagree because they use different dates, harnesses, effort levels, and task revisions; vendor-reported and independent scores are not interchangeable.

## What transfers from strong coding systems

### 1. The harness is part of the measured system

Terminal-Bench reports model + harness entries, and cross-harness comparisons show meaningful score differences for the same model. The safe conclusion is not “copy a giant prompt,” but to version and ablate the entire scaffold: context, tools, output truncation, retries, verifier, and budget.

Sources:
- TerminalFeed harness comparison: https://terminalfeed.io/harnesses
- Terminal-Bench 4.0 public mirror and protocol notes: https://benchlm.ai/benchmarks/vals-terminal-bench-4
- Vals AI public leaderboard: https://valsai.click/benchmarks/terminal-bench-4

### 2. A minimal action space is a strong baseline

mini-SWE-agent demonstrates that a small bash-only loop with linear history and independently executed actions can be competitive with much larger scaffolds. This motivates ProofCoder's tiny protocol and complete audit log rather than a 1.9M-character instruction blob.

Source: https://mini-swe-agent.com/v1

SWE-agent's earlier agent-computer-interface work also motivates concise feedback, useful file navigation/editing, lint/test feedback, and avoiding confusing tool output.

Sources:
- https://swe-agent.com/1.0/background/
- https://arxiv.org/abs/2405.15793

### 3. Execution-verified data is more useful than unverified code text

SWE-smith scales task creation in real repositories and reports SWE-agent-LM-32B at about 40% pass@1 on SWE-bench Verified. The transferable lesson is executable task generation and verified trajectory filtering, not that the same score transfers to a different model or benchmark.

Sources:
- https://swesmith.com/
- https://arxiv.org/abs/2504.21798

R2E-Gym provides procedurally curated executable environments and hybrid verifiers. DeepSWE-Preview is a separate **model/training effort** and should not be confused with the user's DeepSWE v1.1 **benchmark** target. Public descriptions of DeepSWE-Preview emphasize RL in executable environments, multi-file navigation/editing, and test-time scaling.

Source: https://github.com/R2E-Gym/R2E-Gym

### 4. Quantization and training method must match

QLoRA backpropagates through a frozen 4-bit model into LoRA adapters using NF4, double quantization, and paged optimizers. This is the appropriate low-memory starting point, but the paper does not imply that any 27B model fits every pair of GPUs at any context length.

Source: Dettmers et al., https://arxiv.org/abs/2305.14314

NVIDIA lists T4 with 16 GB GDDR6 and FP16/INT8/INT4-oriented Tensor Core performance. T4's Turing architecture does not provide native BF16, so this kit uses FP16 compute.

Source: https://www.nvidia.com/data-center/tesla-t4/

### 5. Public claims about the named frontier models need careful handling

The official VeriLoop E2 model card reports **37.9% Terminal-Bench 4.0** and **64.6% DeepSWE v1.1** for its complete evaluated system, including its internal harness where required. These are not standalone-checkpoint guarantees. The official artifacts are Apache-2.0 and are pinned in the kit.

Sources:
- https://huggingface.co/tsinghua-sigs-robot-lab/VeriLoop-E2
- https://huggingface.co/tsinghua-sigs-robot-lab/VeriLoop-E2-GGUF

DeepSWE v1.1 officially uses 113 original tasks across 91 repositories and five languages, with all models run on mini-swe-agent. Its visible September 22, 2026 leaderboard tops out around 74% for listed configurations; 77% would therefore be a strong new result, not a routine fine-tuning assumption. Kimi K3.1 Pro and Opus 5.5 are not listed in that visible table, so do not invent comparable DeepSWE numbers for them.

Source: https://deepswe.datacurve.ai/

Secondary reporting puts K3.1 Pro and Opus 5.5 near 65.7% and 66.4% on Terminal-Bench 4.0 respectively, but those numbers need the same official protocol before claiming a win. The transferable lessons are larger verified post-training, long-horizon recovery, test-time evidence, and model/harness co-evaluation—not a secret prompt.

Secondary lead only: https://zhuanlan.zhihu.com/p/2097261626986608098

## What not to copy

- Giant prompts that consume context and conflict with the model's existing chat template.
- Self-graded success or “looks correct” web data.
- Training directly on benchmark tasks or near-duplicates.
- Selecting the best of many hidden test runs and calling it pass@1.
- Comparing scores across different harnesses, effort budgets, or benchmark revisions.
- Assuming a larger, more diverse corpus is automatically better than a smaller verified one.

## Highest-value ablations

1. Base model vs base + harness verifier (no training).
2. SFT with vs without failure/recovery traces.
3. Linear full history vs deterministic compaction at equal task budget.
4. Short verified trajectories vs mixed-length trajectories.
5. Rejection-sampling round 1 vs round 2, with fresh dev tasks.
6. Q4 base vs merged/requantized adapter, measuring quantization regression.
7. Test-time 1 vs 3 samples; report both attempt pass@1 and task-any.
