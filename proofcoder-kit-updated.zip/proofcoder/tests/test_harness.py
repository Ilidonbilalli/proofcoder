import json

from proofcoder.harness import AgentConfig, CodingAgent
from proofcoder.sandbox import Observation


class FakeModel:
    def __init__(self, replies):
        self.replies = iter(replies)

    def chat(self, messages, **kwargs):
        return next(self.replies)


class FakeEnv:
    def __init__(self, codes=(0, 0)):
        self.codes = iter(codes)
        self.commands = []

    def run(self, command, timeout=120):
        self.commands.append(command)
        return Observation(next(self.codes), "test evidence", 0.01)


def test_agent_requires_final_verifier(tmp_path):
    env = FakeEnv((0, 1, 0, 0))
    model = FakeModel(["<bash>pytest</bash>", "<done>done</done>", "<bash>fix && pytest</bash>", "<done>done</done>"])
    result = CodingAgent(model, env, AgentConfig(verifier="verify"), str(tmp_path)).run("fix it")
    assert result.resolved
    assert env.commands == ["pytest", "verify", "fix && pytest", "verify"]
    events = [json.loads(x) for x in open(result.trajectory_path, encoding="utf-8")]
    assert events[-1]["resolved"] is True


def test_protocol_error_recovers(tmp_path):
    model = FakeModel(["I think...", "<done>ok</done>"])
    result = CodingAgent(model, FakeEnv(), AgentConfig(), str(tmp_path)).run("task")
    assert not result.resolved
    assert result.reason == "unverified"
    assert result.protocol_errors == 1


def test_repeat_guard(tmp_path):
    model = FakeModel(["<bash>same</bash>"] * 4)
    result = CodingAgent(model, FakeEnv((0, 0, 0)), AgentConfig(repeat_limit=3), str(tmp_path)).run("task")
    assert not result.resolved
    assert result.reason == "repeated_command"


def test_protocol_budget(tmp_path):
    model = FakeModel(["invalid"] * 3)
    result = CodingAgent(model, FakeEnv(), AgentConfig(max_protocol_errors=3), str(tmp_path)).run("task")
    assert result.reason == "protocol_error_budget"


def test_history_compaction(tmp_path):
    model = FakeModel(["<done>ok</done>"])
    agent = CodingAgent(model, FakeEnv(), AgentConfig(max_history_chars=100), str(tmp_path))
    messages = [{"role": "system", "content": "s" * 20}, {"role": "user", "content": "t" * 20}]
    messages += [{"role": "user", "content": str(i) * 30} for i in range(10)]
    trimmed = agent._trim(messages)
    assert trimmed[2]["content"].startswith("<checkpoint>")
    assert sum(len(m["content"]) for m in trimmed) <= 140


def test_agent_accumulates_telemetry(tmp_path):
    model = FakeModel(["<bash>pytest</bash>", "<done>done</done>"])
    model.last_telemetry = {"prompt_tokens": 3, "completion_tokens": 2}
    result = CodingAgent(model, FakeEnv(), AgentConfig(verifier="verify"), str(tmp_path)).run("task")
    assert result.prompt_tokens == 6
    assert result.completion_tokens == 4
    assert result.tool_calls == 1
    assert result.wall_time_s >= 0


def test_backend_failure_is_not_protocol_error(tmp_path):
    class BrokenModel:
        def chat(self, messages, **kwargs):
            raise RuntimeError("server unavailable")

    result = CodingAgent(BrokenModel(), FakeEnv(), AgentConfig(), str(tmp_path)).run("task")
    assert result.reason == "backend_error"
    assert result.protocol_errors == 0


def test_same_task_runs_have_unique_audit_paths(tmp_path):
    agent = CodingAgent(FakeModel(["<done>one</done>", "<done>two</done>"]), FakeEnv(), AgentConfig(), str(tmp_path))
    first = agent.run("same task")
    second = agent.run("same task")
    assert first.trajectory_path != second.trajectory_path


def test_late_verification_cannot_beat_wall_clock(tmp_path, monkeypatch):
    clock = iter([0, 0, 0, 10, 10])
    monkeypatch.setattr("proofcoder.harness.time.monotonic", lambda: next(clock))
    model = FakeModel(["<done>too late</done>"])
    result = CodingAgent(model, FakeEnv(), AgentConfig(verifier="verify", max_wall_time_s=5), str(tmp_path)).run("task")
    assert not result.resolved
    assert result.reason == "wall_time_budget"
