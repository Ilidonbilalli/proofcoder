from proofcoder.data import curate, preference_pairs, trajectory_quality, valid_row


def row(task="a", repo="repo/a", content="<bash>pytest</bash>"):
    return {
        "task_id": task, "repo": repo, "verified": True, "tests_passed": True,
        "final_verification": {"returncode": 0, "output": "passed", "duration_s": 0.1, "timed_out": False},
        "protocol_errors": 0,
        "messages": [
            {"role": "user", "content": f"fix {task}"},
            {"role": "assistant", "content": content},
            {"role": "user", "content": '<observation exit="0">ok</observation>'},
            {"role": "assistant", "content": "<done>fixed</done>"},
        ],
    }


def test_unverified_rejected():
    bad = row()
    bad["verified"] = False
    train, val, stats = curate([bad], set())
    assert not train and stats["rejected"]["unverified"] == 1


def test_contamination_rejected():
    bad = row()
    bad["benchmark_source"] = "secret-test"
    train, val, stats = curate([bad], set())
    assert not train and stats["rejected"]["contamination"] == 1


def test_duplicate_rejected():
    train, val, stats = curate([row("a"), row("b")], set())
    assert len(train) == 1 and stats["rejected"]["duplicate"] == 1


def test_group_split_by_repo():
    rows = [row("a", "repo/a", "<bash>a</bash>"), row("b", "repo/a", "<bash>b</bash>"), row("c", "repo/b", "<bash>c</bash>")]
    train, val, _ = curate(rows, set(), val_fraction=0.5)
    train_repos = {r["repo"] for r in train}
    val_repos = {r["repo"] for r in val}
    assert train_repos.isdisjoint(val_repos)


def test_preference_pair_requires_same_task_and_verified_winner():
    winner = row("same", content="<bash>fix && pytest</bash>")
    loser = row("same", content="<bash>wrong</bash>")
    loser["tests_passed"] = False
    other = row("other", content="<bash>other</bash>")
    other["tests_passed"] = False
    pairs = preference_pairs([winner, loser, other], set())
    assert len(pairs) == 1
    assert pairs[0]["chosen"][-1]["content"] == "<done>fixed</done>"
    assert pairs[0]["rejected"] != pairs[0]["chosen"]


def test_near_duplicate_tasks_rejected():
    first = row("shared", content="<bash>a</bash>")
    second = row("shared", content="<bash>b</bash>")
    train, val, stats = curate([first, second], set())
    assert len(train) == 1
    assert stats["rejected"]["near_duplicate_task"] == 1


def test_quality_requires_final_done():
    bad = row()
    bad["messages"][-1]["content"] = "<bash>pytest</bash>"
    assert not trajectory_quality(bad)["accepted"]
    assert "bad_final_action" in trajectory_quality(bad)["reasons"]


def test_quality_requires_successful_final_verification():
    bad = row()
    bad["final_verification"]["returncode"] = 1
    ok, reason = valid_row(bad, set())
    assert not ok and reason == "missing_final_verification"


def test_quality_rejects_protocol_error_leakage():
    bad = row()
    bad["protocol_errors"] = 1
    assert "protocol_error_leakage" in trajectory_quality(bad)["reasons"]


def test_quality_rejects_malformed_earlier_action():
    bad = row()
    bad["messages"].insert(1, {"role": "assistant", "content": "unstructured plan"})
    assert "invalid_action" in trajectory_quality(bad)["reasons"]


def test_quality_command_repeat_boundary():
    candidate = row()
    messages = candidate["messages"][:1]
    for _ in range(3):
        messages.extend([
            {"role": "assistant", "content": "<bash>pytest</bash>"},
            {"role": "user", "content": '<observation exit="0">ok</observation>'},
        ])
    messages.append({"role": "assistant", "content": "<done>done</done>"})
    candidate["messages"] = messages
    assert trajectory_quality(candidate, max_command_repeats=3)["accepted"]
    messages.insert(-1, {"role": "user", "content": '<observation exit="0">ok</observation>'})
    messages.insert(-2, {"role": "assistant", "content": "<bash>pytest</bash>"})
    assert "repeated_command" in trajectory_quality(candidate, max_command_repeats=3)["reasons"]


def test_quality_action_and_character_bounds():
    candidate = row()
    assert "too_many_actions" in trajectory_quality(candidate, max_actions=1)["reasons"]
    assert "too_long" in trajectory_quality(candidate, max_example_chars=100)["reasons"]


def test_quality_score_ignores_self_praise():
    concise = row()
    verbose = row()
    verbose["messages"][-1]["content"] = "<done>I am absolutely certain this is perfect and correct.</done>"
    first = trajectory_quality(concise)
    second = trajectory_quality(verbose)
    assert first["accepted"] and second["accepted"]
    assert second["score"] <= first["score"]


def test_near_duplicates_cannot_cross_repositories():
    first = row("shared", "repo/a", "<bash>a</bash>")
    second = row("shared", "repo/b", "<bash>b</bash>")
    train, val, stats = curate([first, second], set(), val_fraction=0.5)
    assert len(train) + len(val) == 1
    assert stats["rejected"]["near_duplicate_task"] == 1


def test_preference_winner_rechecks_final_verification():
    winner = row("same")
    winner["final_verification"]["returncode"] = 1
    loser = row("same", content="<bash>wrong</bash>")
    loser["tests_passed"] = False
    loser["verified"] = False
    loser["final_verification"]["returncode"] = 1
    assert preference_pairs([winner, loser], set()) == []
