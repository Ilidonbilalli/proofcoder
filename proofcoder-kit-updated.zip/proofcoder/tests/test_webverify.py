from proofcoder.webverify import static_check


def test_valid_canvas_app(tmp_path):
    (tmp_path / "index.html").write_text('<canvas id="game"></canvas><script>const x = 1;</script>', encoding="utf-8")
    report = static_check(str(tmp_path), require_canvas=True)
    assert report["passed"], report


def test_missing_asset_rejected(tmp_path):
    (tmp_path / "index.html").write_text('<canvas></canvas><script src="missing.js"></script>', encoding="utf-8")
    report = static_check(str(tmp_path), require_canvas=True)
    assert not report["passed"]
    assert "Missing local asset" in report["errors"][0]


def test_canvas_required(tmp_path):
    (tmp_path / "index.html").write_text("<h1>not a game</h1>", encoding="utf-8")
    assert not static_check(str(tmp_path), require_canvas=True)["passed"]


def test_asset_cannot_escape_root(tmp_path):
    app = tmp_path / "app"
    app.mkdir()
    (tmp_path / "secret.js").write_text("const secret = true;", encoding="utf-8")
    (app / "index.html").write_text('<script src="../secret.js"></script>', encoding="utf-8")
    report = static_check(str(app))
    assert not report["passed"]
    assert "escapes" in report["errors"][0]
