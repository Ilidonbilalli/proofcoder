import pytest

from proofcoder.protocol import parse_action


def test_parse_bash():
    assert parse_action("<bash>pytest -q</bash>").content == "pytest -q"


def test_parse_done():
    action = parse_action("<done>Fixed; tests pass.</done>")
    assert action.kind == "done"


@pytest.mark.parametrize("text", ["", "thinking", "<bash></bash>", "<bash>a</bash><bash>b</bash>", "hello<bash>a</bash>"])
def test_reject_ambiguous(text):
    with pytest.raises(ValueError):
        parse_action(text)
