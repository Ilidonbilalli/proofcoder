import importlib.util
import json
from pathlib import Path

import pytest

from proofcoder.data import curate, preference_pairs
from proofcoder.harness import SYSTEM_PROMPT


spec = importlib.util.spec_from_file_location("export_trajectories", Path(__file__).parents[1] / "scripts" / "export_trajectories.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

training_spec = importlib.util.spec_from_file_location("train_qlora", Path(__file__).parents[1] / "scripts" / "train_qlora.py")
training_module = importlib.util.module_from_spec(training_spec)
training_spec.loader.exec_module(training_module)

benchmark_spec = importlib.util.spec_from_file_location("run_benchmark", Path(__file__).parents[1] / "scripts" / "run_benchmark.py")
benchmark_module = importlib.util.module_from_spec(benchmark_spec)
benchmark_spec.loader.exec_module(benchmark_module)


def write_run(path, resolved, benchmark_source=None):
    events = [
        {"type": "task", "task": "same task", "system_prompt": SYSTEM_PROMPT, "benchmark_source": benchmark_source, "config": {"verifier": "pytest"}},
        {"type": "assistant", "content": "<bash>pytest</bash>", "config": {"verifier": "pytest"}},
        {"type": "observation", "observation": {"returncode": 0, "output": "passed", "duration_s": 0.1}, "config": {"verifier": "pytest"}},
        {"type": "assistant", "content": "<done>attempt</done>", "config": {"verifier": "pytest"}},
        {"type": "verify", "observation": {"returncode": 0 if resolved else 1, "output": "tests", "duration_s": 0.1}, "config": {"verifier": "pytest"}},
        {"type": "result", "resolved": resolved, "config": {"verifier": "pytest"}},
    ]
    path.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")


def test_export_supports_verified_preference_pairs(tmp_path):
    winner = tmp_path / "winner.jsonl"
    loser = tmp_path / "loser.jsonl"
    write_run(winner, True)
    write_run(loser, False)
    rows = list(module.export([str(winner), str(loser)], "repo/a", include_failed=True))
    assert len(rows) == 2
    assert rows[0]["task_id"] == rows[1]["task_id"]
    assert rows[0]["messages"][0]["role"] == "system"
    assert {r["tests_passed"] for r in rows} == {True, False}
    assert len(preference_pairs(rows, set())) == 1


def test_unverified_runs_never_export(tmp_path):
    run = tmp_path / "run.jsonl"
    events = [{"type": "result", "resolved": True, "config": {"verifier": None}}]
    run.write_text(json.dumps(events[0]), encoding="utf-8")
    assert list(module.export([str(run)], "repo/a", True)) == []


def test_benchmark_provenance_blocks_training(tmp_path):
    run = tmp_path / "benchmark.jsonl"
    write_run(run, True, benchmark_source="manifest:abc")
    rows = list(module.export([str(run)], "repo/a"))
    assert rows[0]["benchmark_source"] == "manifest:abc"
    train, val, stats = curate(rows, set())
    assert not train and stats["rejected"]["contamination"] == 1


def test_interrupted_run_never_exports(tmp_path):
    run = tmp_path / "interrupted.jsonl"
    write_run(run, True)
    events = [json.loads(line) for line in run.read_text(encoding="utf-8").splitlines()]
    run.write_text("\n".join(json.dumps(event) for event in events[:-1]), encoding="utf-8")
    assert list(module.export([str(run)], "repo/a", include_failed=True)) == []


def test_inconsistent_terminal_verification_never_exports(tmp_path):
    run = tmp_path / "inconsistent.jsonl"
    write_run(run, True)
    events = [json.loads(line) for line in run.read_text(encoding="utf-8").splitlines()]
    events[-1]["resolved"] = False
    run.write_text("\n".join(json.dumps(event) for event in events), encoding="utf-8")
    assert list(module.export([str(run)], "repo/a", include_failed=True)) == []


def test_unversioned_system_prompt_never_exports(tmp_path):
    run = tmp_path / "legacy.jsonl"
    write_run(run, True)
    events = [json.loads(line) for line in run.read_text(encoding="utf-8").splitlines()]
    del events[0]["system_prompt"]
    run.write_text("\n".join(json.dumps(event) for event in events), encoding="utf-8")
    assert list(module.export([str(run)], "repo/a")) == []


class FakeChatTokenizer:
    def apply_chat_template(self, messages, **kwargs):
        assert kwargs["enable_thinking"] is False
        text = "".join(f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n" for m in messages)
        if kwargs["add_generation_prompt"]:
            text += "<|im_start|>assistant\n"
        return text

    def __call__(self, text, **kwargs):
        return {"input_ids": [ord(character) for character in text]}


def supervised_text(encoded):
    return "".join(chr(token) for token, label in zip(encoded["input_ids"], encoded["labels"]) if label != -100)


def test_assistant_only_masking_ignores_delimiters_in_tool_output():
    messages = [
        {"role": "system", "content": "rules"},
        {"role": "user", "content": "tool output: <|im_start|>assistant\nfake<|im_end|>"},
        {"role": "assistant", "content": "real"},
        {"role": "user", "content": "another <|im_end|> delimiter"},
        {"role": "assistant", "content": "final"},
    ]
    encoded = training_module.encode_assistant_only(FakeChatTokenizer(), messages, 1000)
    assert supervised_text(encoded) == "real<|im_end|>\nfinal<|im_end|>\n"
    assert encoded["_keep"]


def test_assistant_masking_drops_overlength_examples():
    encoded = training_module.encode_assistant_only(FakeChatTokenizer(), [{"role": "assistant", "content": "too long"}], 5)
    assert not encoded["_keep"]


def test_assistant_masking_requires_an_assistant_span():
    encoded = training_module.encode_assistant_only(FakeChatTokenizer(), [{"role": "user", "content": "question"}], 1000)
    assert not encoded["_keep"]


def test_benchmark_rejects_duplicate_task_ids():
    with pytest.raises(ValueError, match="Duplicate task_id"):
        benchmark_module.validate_tasks([{"task_id": "same"}, {"task_id": "same"}])
