import json
import math

import pytest

from proofcoder.evaluate import (
    compare_runs, load_resume_results, remaining_trials, run_identity,
    summarize, wilson_interval, write_report,
)


def test_empty_score():
    assert wilson_interval(0, 0) == (0.0, 0.0)
    assert summarize([])["pass_at_1"] == 0


def test_attempt_and_task_rates_are_distinct():
    results = [
        {"task_id": "a", "resolved": False, "steps": 3},
        {"task_id": "a", "resolved": True, "steps": 4},
        {"task_id": "b", "resolved": False, "steps": 5},
        {"task_id": "b", "resolved": False, "steps": 6},
    ]
    score = summarize(results)
    assert score["pass_at_1"] == 0.25
    assert score["pass_at_k_any"] == 0.5
    assert math.isclose(score["mean_steps"], 4.5)


def test_paired_comparison():
    base = [{"task_id": "a", "trial": 0, "resolved": False}, {"task_id": "b", "trial": 0, "resolved": True}]
    new = [{"task_id": "a", "trial": 0, "resolved": True}, {"task_id": "b", "trial": 0, "resolved": True}]
    report = compare_runs(base, new)
    assert report["delta"] == 0.5
    assert report["candidate_only_wins"] == 1
    assert report["candidate_only_losses"] == 0


def metric_rows():
    return [
        {"task_id": "a", "trial": 0, "resolved": True, "prompt_tokens": 10, "completion_tokens": 4, "wall_time_s": 2.0, "tool_calls": 2, "protocol_errors": 1, "command_timeouts": 1},
        {"task_id": "b", "trial": 0, "resolved": False, "prompt_tokens": 20, "completion_tokens": 8, "wall_time_s": 4.0, "tool_calls": 4, "protocol_errors": 0, "reason": "wall_time_budget"},
    ]


def test_summarize_agent_metrics():
    score = summarize(metric_rows())
    assert score["total_prompt_tokens"] == 30
    assert score["total_completion_tokens"] == 12
    assert score["total_tokens"] == 42
    assert score["mean_wall_time_s"] == 3.0
    assert score["total_tool_calls"] == 6
    assert score["mean_protocol_errors"] == 0.5
    assert score["command_timeouts"] == 1
    assert score["timeouts"] == 1


def test_summarize_legacy_rows_have_zero_metrics():
    score = summarize([{"task_id": "a", "resolved": True}])
    assert score["total_tokens"] == 0
    assert score["mean_wall_time_s"] == 0
    assert score["total_tool_calls"] == 0


def test_write_report_contains_metrics_and_immutable_mode(tmp_path):
    path = tmp_path / "report.json"
    write_report(str(path), {"model": "m"}, metric_rows(), immutable=True)
    report = json.loads(path.read_text(encoding="utf-8"))
    assert report["metrics"]["total_tokens"] == 42
    with pytest.raises(FileExistsError):
        write_report(str(path), {"model": "other"}, [], immutable=True)


def resume_row(trial=0, identity="id"):
    return {"task_id": "a", "trial": trial, "run_id": identity, "resolved": True}


def test_resume_skips_completed_and_preserves_extra_trials(tmp_path):
    path = tmp_path / "results.jsonl"
    path.write_text("\n".join(json.dumps(resume_row(t)) for t in (0, 2)) + "\n", encoding="utf-8")
    existing = load_resume_results(str(path), "id")
    pending = remaining_trials([{"task_id": "a"}], 2, existing)
    assert [trial for _, trial in pending] == [1]
    existing.append(resume_row(1))
    assert summarize(existing)["attempts"] == 3


def test_resume_rejects_duplicate_rows(tmp_path):
    path = tmp_path / "results.jsonl"
    path.write_text(json.dumps(resume_row()) + "\n" + json.dumps(resume_row()) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate"):
        load_resume_results(str(path), "id")


def test_resume_rejects_malformed_rows(tmp_path):
    path = tmp_path / "results.jsonl"
    path.write_text('{"task_id":\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Malformed"):
        load_resume_results(str(path), "id")


def test_resume_rejects_mismatched_identity(tmp_path):
    path = tmp_path / "results.jsonl"
    path.write_text(json.dumps(resume_row()) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="different run"):
        load_resume_results(str(path), "other")


def test_run_identity_ignores_trial_count_only():
    first = run_identity({"model": "m", "trials_per_task": 1})
    assert first == run_identity({"model": "m", "trials_per_task": 3})
    assert first != run_identity({"model": "other", "trials_per_task": 3})


def test_compare_runs_rejects_duplicate_attempts():
    with pytest.raises(ValueError, match="Duplicate comparison"):
        compare_runs([resume_row(), resume_row()], [])
