import pytest

from proofcoder.evaluate import classify_failure


@pytest.mark.parametrize("reason,expected", [
    ("step_budget", "budget"),
    ("wall_time_budget", "budget"),
    ("no_progress", "recovery"),
    ("repeated_command", "recovery"),
    ("protocol_error_budget", "protocol"),
    ("backend_error", "protocol"),
    ("timeout", "environment"),
    ("unknown", "unknown"),
])
def test_classify_failure(reason, expected):
    assert classify_failure(reason) == expected
