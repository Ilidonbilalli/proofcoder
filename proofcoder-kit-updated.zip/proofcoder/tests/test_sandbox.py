from proofcoder.sandbox import LocalEnvironment, compact_output


def test_compact_output_keeps_ends():
    output = compact_output("a" * 100 + "MIDDLE" + "z" * 100, 50)
    assert output.startswith("a")
    assert output.endswith("z")
    assert "truncated" in output


def test_local_execution(tmp_path):
    result = LocalEnvironment(str(tmp_path)).run("python -c \"print('ok')\"")
    assert result.returncode == 0
    assert "ok" in result.output
