import io
import json

import pytest
from urllib.error import HTTPError, URLError

import proofcoder.backends as backend_module
from proofcoder.backends import OpenAICompatibleBackend


def response(content="ok", completion_tokens=1, prompt_tokens=2):
    body = {"choices": [{"message": {"content": content}}], "usage": {"completion_tokens": completion_tokens, "prompt_tokens": prompt_tokens}}
    return io.BytesIO(json.dumps(body).encode())


class FakeContext:
    def __init__(self, stream):
        self.stream = stream
    def __enter__(self):
        return self.stream
    def __exit__(self, *_):
        self.stream.close()


def make_backend(**kwargs):
    return OpenAICompatibleBackend("http://localhost/v1", "m", max_retries=kwargs.pop("max_retries", 2), retry_backoff_s=0, **kwargs)


def test_telemetry_reported(monkeypatch):
    monkeypatch.setattr(backend_module, "urlopen", lambda *a, **k: FakeContext(response()))
    backend = make_backend()
    result = backend.chat([{"role": "user", "content": "x"}], max_tokens=4, temperature=0, seed=1)
    assert result == "ok"
    assert backend.last_telemetry["prompt_tokens"] == 2
    assert backend.last_telemetry["completion_tokens"] == 1
    assert backend.last_telemetry["decode_tokens_per_second"] > 0


def test_chat_template_kwargs_are_forwarded(monkeypatch):
    seen = {}
    def capture(request, **kwargs):
        seen.update(json.loads(request.data))
        return FakeContext(response())
    monkeypatch.setattr(backend_module, "urlopen", capture)
    make_backend(chat_template_kwargs={"enable_thinking": False}).chat([], max_tokens=1, temperature=0, seed=1)
    assert seen["chat_template_kwargs"] == {"enable_thinking": False}


def test_transient_error_retries(monkeypatch):
    calls = {"count": 0}
    def flaky(*args, **kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            raise URLError("temporary")
        return FakeContext(response("recovered"))
    monkeypatch.setattr(backend_module, "urlopen", flaky)
    assert make_backend().chat([], max_tokens=1, temperature=0, seed=1) == "recovered"
    assert calls["count"] == 2


@pytest.mark.parametrize("status", [400, 401, 403])
def test_client_error_not_retried(monkeypatch, status):
    calls = {"count": 0}
    def fail(*args, **kwargs):
        calls["count"] += 1
        raise HTTPError("url", status, "bad", None, None)
    monkeypatch.setattr(backend_module, "urlopen", fail)
    with pytest.raises(HTTPError):
        make_backend().chat([], max_tokens=1, temperature=0, seed=1)
    assert calls["count"] == 1


def test_server_error_exhausts_retries(monkeypatch):
    calls = {"count": 0}
    def fail(*args, **kwargs):
        calls["count"] += 1
        raise HTTPError("url", 503, "down", None, None)
    monkeypatch.setattr(backend_module, "urlopen", fail)
    with pytest.raises(HTTPError):
        make_backend().chat([], max_tokens=1, temperature=0, seed=1)
    assert calls["count"] == 3
