#!/usr/bin/env bash
set -euo pipefail
: "${HF_REPO_ID:?Set HF_REPO_ID}"
: "${HF_GGUF_FILE:?Set HF_GGUF_FILE}"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq build-essential cmake git curl tailscale > /dev/null
python -m pip install -q huggingface_hub
if [ ! -d /kaggle/working/llama.cpp ]; then
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git /kaggle/working/llama.cpp
fi
cmake -S /kaggle/working/llama.cpp -B /kaggle/working/llama.cpp/build -DGGML_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=75 -DCMAKE_BUILD_TYPE=Release
cmake --build /kaggle/working/llama.cpp/build --config Release --target llama-server -j 4
mkdir -p /kaggle/working/models
python - <<'PY'
import os
from huggingface_hub import hf_hub_download
path = hf_hub_download(
    repo_id=os.environ["HF_REPO_ID"],
    filename=os.environ["HF_GGUF_FILE"],
    revision=os.environ.get("HF_REVISION") or None,
    token=os.environ.get("HF_TOKEN") or None,
    local_dir="/kaggle/working/models",
)
print("MODEL_PATH=" + path)
PY
ln -sf /kaggle/working/llama.cpp/build/bin/llama-server /usr/local/bin/llama-server
nvidia-smi
