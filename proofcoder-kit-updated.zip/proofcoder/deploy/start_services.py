"""Start authenticated inference and private Tailscale access inside Kaggle."""

import json
import os
from pathlib import Path
import subprocess
import time
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
WORK = Path("/kaggle/working")
LOGS = WORK / "logs"
LOGS.mkdir(parents=True, exist_ok=True)
required = ["MODEL_PATH", "LLAMA_API_KEY", "TAILSCALE_AUTH_KEY"]
missing = [name for name in required if not os.environ.get(name)]
if missing:
    raise SystemExit("Missing environment variables: " + ", ".join(missing))


def launch(name, command):
    log = (LOGS / f"{name}.log").open("ab", buffering=0)
    process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=os.environ.copy())
    (LOGS / f"{name}.pid").write_text(str(process.pid))
    return process


llama = launch("llama-server", ["bash", str(ROOT / "scripts" / "serve_gguf.sh")])
tailscaled = launch("tailscaled", ["tailscaled", "--tun=userspace-networking", f"--state={WORK / 'tailscale.state'}"])

for attempt in range(60):
    try:
        with urlopen("http://127.0.0.1:8000/health", timeout=2) as response:
            if response.status == 200:
                break
    except Exception:
        if llama.poll() is not None:
            raise RuntimeError("llama-server exited; inspect /kaggle/working/logs/llama-server.log")
        time.sleep(2)
else:
    raise RuntimeError("Inference health check timed out.")

subprocess.run(["tailscale", "up", f"--auth-key={os.environ['TAILSCALE_AUTH_KEY']}", "--hostname=proofcoder-kaggle", "--timeout=120s"], check=True)
subprocess.run(["tailscale", "serve", "--bg", "--yes", "8000"], check=True)
status = json.loads(subprocess.check_output(["tailscale", "status", "--json"], text=True))
dns = status.get("Self", {}).get("DNSName", "").rstrip(".")
print("PRIVATE_BASE_URL=https://" + dns + "/v1")
print("MODEL_ALIAS=" + os.environ.get("MODEL_ALIAS", "veriloop-e2-27b-q4"))
print("Keep the Kaggle session running. The URL and GPU worker are temporary.")
